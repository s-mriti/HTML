<?php
/**
 * Main Index Template (Fallback)
 *
 * WordPress requires this file. For the Serenova theme,
 * the front-page.php handles the homepage. This file is
 * a safe fallback for any other page type that lacks a
 * dedicated template.
 *
 * @package Serenova
 */

get_header();
?>

<main style="min-height:60vh; display:flex; align-items:center; justify-content:center; padding: 120px 40px 80px;">
  <div style="text-align:center; max-width:600px;">
    <h1 style="font-family:'Marcellus',serif; font-size:clamp(28px,5vw,48px); color:var(--deep-green); margin-bottom:20px;">
      <?php echo esc_html( get_bloginfo( 'name' ) ); ?>
    </h1>

    <?php if ( have_posts() ) : ?>
      <?php while ( have_posts() ) : the_post(); ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
          <h2 style="font-family:'Cormorant Garamond',serif; font-size:28px; margin-bottom:16px; color:var(--forest);">
            <a href="<?php the_permalink(); ?>" style="text-decoration:none; color:inherit;"><?php the_title(); ?></a>
          </h2>
          <div style="font-size:15px; line-height:1.8; color:var(--charcoal); margin-bottom:24px;">
            <?php the_excerpt(); ?>
          </div>
        </article>
      <?php endwhile; ?>
    <?php else : ?>
      <p style="font-size:16px; color:rgba(42,42,42,0.6);">
        <?php esc_html_e( 'No content found. Please check back soon.', 'serenova' ); ?>
      </p>
    <?php endif; ?>

    <a href="<?php echo esc_url( home_url( '/' ) ); ?>"
       style="display:inline-block; margin-top:32px; padding:14px 36px; background:var(--forest);
              color:var(--cream); font-size:13px; letter-spacing:0.12em; text-transform:uppercase;
              text-decoration:none; border-radius:2px;">
      <?php esc_html_e( '← Return Home', 'serenova' ); ?>
    </a>
  </div>
</main>

<?php get_footer(); ?>
