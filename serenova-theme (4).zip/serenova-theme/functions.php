<?php
/**
 * Serenova Theme Functions
 *
 * @package Serenova
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ─── Theme Setup ────────────────────────────────────────────────────────────

add_action( 'after_setup_theme', 'serenova_setup' );
function serenova_setup() {
	load_theme_textdomain( 'serenova', get_template_directory() . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', [ 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ] );
	add_theme_support( 'custom-logo', [
		'height'      => 60,
		'width'       => 200,
		'flex-height' => true,
		'flex-width'  => true,
	] );
	add_theme_support( 'customize-selective-refresh-widgets' );

	register_nav_menus( [
		'primary' => __( 'Primary Navigation', 'serenova' ),
	] );
}

// ─── Enqueue Styles & Scripts ────────────────────────────────────────────────

add_action( 'wp_enqueue_scripts', 'serenova_enqueue_assets' );
function serenova_enqueue_assets() {
	$ver = wp_get_theme()->get( 'Version' );

	// Google Fonts
	wp_enqueue_style(
		'serenova-fonts',
		'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:wght@300;400;500&family=Marcellus&display=swap',
		[],
		null
	);

	// Main stylesheet
	wp_enqueue_style(
		'serenova-style',
		get_template_directory_uri() . '/assets/css/serenova.css',
		[ 'serenova-fonts' ],
		$ver
	);

	// GSAP
	wp_enqueue_script(
		'gsap',
		'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js',
		[],
		'3.12.5',
		true
	);
	wp_enqueue_script(
		'gsap-scroll-trigger',
		'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js',
		[ 'gsap' ],
		'3.12.5',
		true
	);

	// Three.js
	wp_enqueue_script(
		'threejs',
		'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js',
		[],
		'r128',
		true
	);

	// Main theme JS
	wp_enqueue_script(
		'serenova-main',
		get_template_directory_uri() . '/assets/js/serenova.js',
		[ 'gsap', 'gsap-scroll-trigger', 'threejs' ],
		$ver,
		true
	);

	// Pass dynamic data to JS (e.g. AJAX URL, site URL)
	wp_localize_script( 'serenova-main', 'serenovaData', [
		'ajaxUrl' => admin_url( 'admin-ajax.php' ),
		'nonce'   => wp_create_nonce( 'serenova_nonce' ),
		'siteUrl' => get_site_url(),
	] );
}

// ─── Newsletter / Contact AJAX Handler ───────────────────────────────────────

add_action( 'wp_ajax_serenova_newsletter', 'serenova_newsletter_handler' );
add_action( 'wp_ajax_nopriv_serenova_newsletter', 'serenova_newsletter_handler' );
function serenova_newsletter_handler() {
	check_ajax_referer( 'serenova_nonce', 'nonce' );

	$email = isset( $_POST['email'] ) ? sanitize_email( $_POST['email'] ) : '';
	if ( ! is_email( $email ) ) {
		wp_send_json_error( [ 'message' => __( 'Please enter a valid email address.', 'serenova' ) ] );
	}

	// Store subscriber in a custom DB table or post type.
	// For now we save as a custom post type entry:
	$exists = get_posts( [
		'post_type'   => 'serenova_subscriber',
		'title'       => $email,
		'post_status' => 'any',
		'numberposts' => 1,
	] );

	if ( $exists ) {
		wp_send_json_error( [ 'message' => __( 'You are already subscribed!', 'serenova' ) ] );
	}

	$post_id = wp_insert_post( [
		'post_type'   => 'serenova_subscriber',
		'post_title'  => $email,
		'post_status' => 'publish',
	] );

	if ( $post_id ) {
		wp_send_json_success( [ 'message' => __( 'Thank you! Your journey begins now.', 'serenova' ) ] );
	} else {
		wp_send_json_error( [ 'message' => __( 'Something went wrong. Please try again.', 'serenova' ) ] );
	}
}

// ─── Register Custom Post Types ───────────────────────────────────────────────

add_action( 'init', 'serenova_register_post_types' );
function serenova_register_post_types() {

	// Testimonials
	register_post_type( 'serenova_testimonial', [
		'labels'    => [
			'name'          => __( 'Testimonials', 'serenova' ),
			'singular_name' => __( 'Testimonial', 'serenova' ),
			'add_new_item'  => __( 'Add New Testimonial', 'serenova' ),
		],
		'public'       => false,
		'show_ui'      => true,
		'show_in_menu' => true,
		'supports'     => [ 'title', 'editor', 'thumbnail' ],
		'menu_icon'    => 'dashicons-format-quote',
	] );

	// Courses / Offerings
	register_post_type( 'serenova_course', [
		'labels'    => [
			'name'          => __( 'Courses', 'serenova' ),
			'singular_name' => __( 'Course', 'serenova' ),
			'add_new_item'  => __( 'Add New Course', 'serenova' ),
		],
		'public'       => false,
		'show_ui'      => true,
		'show_in_menu' => true,
		'supports'     => [ 'title', 'editor', 'thumbnail', 'custom-fields' ],
		'menu_icon'    => 'dashicons-awards',
	] );

	// Team Members
	register_post_type( 'serenova_team', [
		'labels'    => [
			'name'          => __( 'Team Members', 'serenova' ),
			'singular_name' => __( 'Team Member', 'serenova' ),
			'add_new_item'  => __( 'Add New Team Member', 'serenova' ),
			'edit_item'     => __( 'Edit Team Member', 'serenova' ),
		],
		'public'       => true,
		'show_ui'      => true,
		'show_in_menu' => true,
		'supports'     => [ 'title', 'editor', 'thumbnail', 'custom-fields', 'page-attributes' ],
		'menu_icon'    => 'dashicons-groups',
		'has_archive'  => false,
		'rewrite'      => [ 'slug' => 'team' ],
	] );

	// Newsletter Subscribers (private storage)
	register_post_type( 'serenova_subscriber', [
		'labels'       => [
			'name'          => __( 'Subscribers', 'serenova' ),
			'singular_name' => __( 'Subscriber', 'serenova' ),
		],
		'public'       => false,
		'show_ui'      => true,
		'show_in_menu' => true,
		'supports'     => [ 'title' ],
		'menu_icon'    => 'dashicons-email-alt',
	] );
}

// ─── Theme Customizer Options ─────────────────────────────────────────────────

add_action( 'customize_register', 'serenova_customizer' );
function serenova_customizer( $wp_customize ) {

	// ── Section: Hero ──
	$wp_customize->add_section( 'serenova_hero', [
		'title'    => __( 'Hero Section', 'serenova' ),
		'priority' => 30,
	] );
	$wp_customize->add_setting( 'serenova_hero_eyebrow', [
		'default'           => '✦ Holistic Wellness Redefined ✦',
		'sanitize_callback' => 'sanitize_text_field',
	] );
	$wp_customize->add_control( 'serenova_hero_eyebrow', [
		'label'   => __( 'Hero Eyebrow Text', 'serenova' ),
		'section' => 'serenova_hero',
		'type'    => 'text',
	] );
	$wp_customize->add_setting( 'serenova_hero_title_line1', [
		'default'           => 'Where Wellness',
		'sanitize_callback' => 'sanitize_text_field',
	] );
	$wp_customize->add_control( 'serenova_hero_title_line1', [
		'label'   => __( 'Hero Title — Line 1', 'serenova' ),
		'section' => 'serenova_hero',
		'type'    => 'text',
	] );
	$wp_customize->add_setting( 'serenova_hero_title_line2', [
		'default'           => 'Becomes a Way of Life',
		'sanitize_callback' => 'sanitize_text_field',
	] );
	$wp_customize->add_control( 'serenova_hero_title_line2', [
		'label'   => __( 'Hero Title — Line 2 (italic)', 'serenova' ),
		'section' => 'serenova_hero',
		'type'    => 'text',
	] );
	$wp_customize->add_setting( 'serenova_hero_sub', [
		'default'           => 'Yoga · Swimming · Mindfulness · Diet · Stress Relief — all within one extraordinary sanctuary.',
		'sanitize_callback' => 'sanitize_text_field',
	] );
	$wp_customize->add_control( 'serenova_hero_sub', [
		'label'   => __( 'Hero Subheading', 'serenova' ),
		'section' => 'serenova_hero',
		'type'    => 'textarea',
	] );

	// ── Section: Contact Info ──
	$wp_customize->add_section( 'serenova_contact', [
		'title'    => __( 'Contact & Location', 'serenova' ),
		'priority' => 40,
	] );
	$wp_customize->add_setting( 'serenova_address', [
		'default'           => 'Gurugram, Haryana',
		'sanitize_callback' => 'sanitize_text_field',
	] );
	$wp_customize->add_control( 'serenova_address', [
		'label'   => __( 'Address', 'serenova' ),
		'section' => 'serenova_contact',
		'type'    => 'text',
	] );
	$wp_customize->add_setting( 'serenova_email', [
		'default'           => 'hello@serenova.in',
		'sanitize_callback' => 'sanitize_email',
	] );
	$wp_customize->add_control( 'serenova_email', [
		'label'   => __( 'Email', 'serenova' ),
		'section' => 'serenova_contact',
		'type'    => 'email',
	] );
	$wp_customize->add_setting( 'serenova_phone', [
		'default'           => '+91 98765 43210',
		'sanitize_callback' => 'sanitize_text_field',
	] );
	$wp_customize->add_control( 'serenova_phone', [
		'label'   => __( 'Phone', 'serenova' ),
		'section' => 'serenova_contact',
		'type'    => 'text',
	] );

	// ── Section: Social Links ──
	$wp_customize->add_section( 'serenova_social', [
		'title'    => __( 'Social Media Links', 'serenova' ),
		'priority' => 50,
	] );
	foreach ( [ 'twitter' => 'Twitter / X URL', 'linkedin' => 'LinkedIn URL', 'instagram' => 'Instagram URL', 'youtube' => 'YouTube URL' ] as $key => $label ) {
		$wp_customize->add_setting( 'serenova_' . $key, [
			'default'           => '#',
			'sanitize_callback' => 'esc_url_raw',
		] );
		$wp_customize->add_control( 'serenova_' . $key, [
			'label'   => __( $label, 'serenova' ),
			'section' => 'serenova_social',
			'type'    => 'url',
		] );
	}

	// ── Section: Join Us CTA Button ──
	$wp_customize->add_section( 'serenova_joinus', [
		'title'       => __( 'Join Us Button', 'serenova' ),
		'description' => __( 'The "Join Us" call-to-action button that appears in the nav and hero. Paste your enrollment or registration URL here.', 'serenova' ),
		'priority'    => 35,
	] );
	$wp_customize->add_setting( 'serenova_joinus_url', [
		'default'           => '#newsletter',
		'sanitize_callback' => 'esc_url_raw',
	] );
	$wp_customize->add_control( 'serenova_joinus_url', [
		'label'       => __( 'Join Us URL', 'serenova' ),
		'description' => __( 'e.g. https://forms.google.com/your-form or https://yoursite.com/enroll', 'serenova' ),
		'section'     => 'serenova_joinus',
		'type'        => 'url',
	] );
	$wp_customize->add_setting( 'serenova_joinus_label', [
		'default'           => 'Join Us',
		'sanitize_callback' => 'sanitize_text_field',
	] );
	$wp_customize->add_control( 'serenova_joinus_label', [
		'label'   => __( 'Button Label', 'serenova' ),
		'section' => 'serenova_joinus',
		'type'    => 'text',
	] );
	$wp_customize->add_setting( 'serenova_joinus_target', [
		'default'           => '_blank',
		'sanitize_callback' => 'sanitize_text_field',
	] );
	$wp_customize->add_control( 'serenova_joinus_target', [
		'label'   => __( 'Open in', 'serenova' ),
		'section' => 'serenova_joinus',
		'type'    => 'select',
		'choices' => [
			'_blank' => __( 'New tab', 'serenova' ),
			'_self'  => __( 'Same tab', 'serenova' ),
		],
	] );
}

// ─── Helper: Get Theme Mod with fallback ─────────────────────────────────────

function serenova_get( $key, $fallback = '' ) {
	return get_theme_mod( $key, $fallback );
}

// ─── Team Member Meta Boxes ──────────────────────────────────────────────────

add_action( 'add_meta_boxes', 'serenova_team_meta_boxes' );
function serenova_team_meta_boxes() {
	add_meta_box(
		'serenova_team_details',
		__( 'Team Member Details', 'serenova' ),
		'serenova_team_meta_callback',
		'serenova_team',
		'normal',
		'high'
	);
}

function serenova_team_meta_callback( $post ) {
	wp_nonce_field( 'serenova_team_save', 'serenova_team_nonce' );
	$role        = get_post_meta( $post->ID, 'serenova_team_role', true );
	$speciality  = get_post_meta( $post->ID, 'serenova_team_speciality', true );
	$linkedin    = get_post_meta( $post->ID, 'serenova_team_linkedin', true );
	$instagram   = get_post_meta( $post->ID, 'serenova_team_instagram', true );
	$email       = get_post_meta( $post->ID, 'serenova_team_email', true );
	$quote       = get_post_meta( $post->ID, 'serenova_team_quote', true );
	?>
	<style>
		.serenova-meta-grid { display:grid; grid-template-columns:1fr 1fr; gap:16px; padding:8px 0; }
		.serenova-meta-grid label { display:block; font-weight:600; margin-bottom:4px; font-size:13px; }
		.serenova-meta-grid input, .serenova-meta-grid textarea {
			width:100%; padding:8px 10px; border:1px solid #ddd; border-radius:4px; font-size:13px;
		}
		.serenova-meta-full { grid-column: 1 / -1; }
	</style>
	<div class="serenova-meta-grid">
		<div>
			<label><?php esc_html_e( 'Job Title / Role', 'serenova' ); ?></label>
			<input type="text" name="serenova_team_role" value="<?php echo esc_attr( $role ); ?>" placeholder="e.g. Lead Yoga Instructor" />
		</div>
		<div>
			<label><?php esc_html_e( 'Speciality', 'serenova' ); ?></label>
			<input type="text" name="serenova_team_speciality" value="<?php echo esc_attr( $speciality ); ?>" placeholder="e.g. Hatha · Vinyasa · Breathwork" />
		</div>
		<div>
			<label><?php esc_html_e( 'LinkedIn URL', 'serenova' ); ?></label>
			<input type="url" name="serenova_team_linkedin" value="<?php echo esc_attr( $linkedin ); ?>" placeholder="https://linkedin.com/in/name" />
		</div>
		<div>
			<label><?php esc_html_e( 'Instagram URL', 'serenova' ); ?></label>
			<input type="url" name="serenova_team_instagram" value="<?php echo esc_attr( $instagram ); ?>" placeholder="https://instagram.com/handle" />
		</div>
		<div>
			<label><?php esc_html_e( 'Email (optional)', 'serenova' ); ?></label>
			<input type="email" name="serenova_team_email" value="<?php echo esc_attr( $email ); ?>" placeholder="name@serenova.in" />
		</div>
		<div class="serenova-meta-full">
			<label><?php esc_html_e( 'Personal Quote (shown on card)', 'serenova' ); ?></label>
			<textarea name="serenova_team_quote" rows="2" placeholder="e.g. Wellness is a daily practice, not a destination."><?php echo esc_textarea( $quote ); ?></textarea>
		</div>
	</div>
	<p style="color:#666; font-size:12px; margin-top:8px;">
		💡 <strong><?php esc_html_e( 'Tip:', 'serenova' ); ?></strong>
		<?php esc_html_e( 'Set a Featured Image for the member\'s photo. Use the body/content area for their full bio.', 'serenova' ); ?>
	</p>
	<?php
}

add_action( 'save_post_serenova_team', 'serenova_team_save_meta' );
function serenova_team_save_meta( $post_id ) {
	if ( ! isset( $_POST['serenova_team_nonce'] ) ) return;
	if ( ! wp_verify_nonce( $_POST['serenova_team_nonce'], 'serenova_team_save' ) ) return;
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	if ( ! current_user_can( 'edit_post', $post_id ) ) return;

	$fields = [ 'serenova_team_role', 'serenova_team_speciality', 'serenova_team_linkedin', 'serenova_team_instagram', 'serenova_team_email', 'serenova_team_quote' ];
	foreach ( $fields as $field ) {
		if ( isset( $_POST[ $field ] ) ) {
			update_post_meta( $post_id, $field, sanitize_text_field( $_POST[ $field ] ) );
		}
	}
}

// ─── Add body class for front page ───────────────────────────────────────────

add_filter( 'body_class', 'serenova_body_classes' );
function serenova_body_classes( $classes ) {
	if ( is_front_page() ) {
		$classes[] = 'serenova-front';
	}
	return $classes;
}
