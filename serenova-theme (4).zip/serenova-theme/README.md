# Serenova WordPress Theme

A premium holistic wellness landing page theme. Convert your `serenova-landing.zip` HTML into a fully functional WordPress theme.

---

## Installation

1. Upload the `serenova-theme` folder to `/wp-content/themes/`
2. In WordPress Admin → **Appearance → Themes**, activate **Serenova**
3. Go to **Settings → Reading** → set *Your homepage displays* to **A static page**, select any page as your homepage
4. The front page template (`front-page.php`) will render the full landing page automatically

---

## File Structure

```
serenova-theme/
├── style.css                          ← Theme header (required by WordPress)
├── index.php                          ← Fallback template
├── front-page.php                     ← Main landing page
├── header.php                         ← <head>, nav
├── footer.php                         ← Footer + wp_footer()
├── functions.php                      ← Enqueues, CPTs, Customizer, AJAX
├── screenshot.png                     ← Theme preview (1200×900px recommended)
│
├── assets/
│   ├── css/
│   │   └── serenova.css               ← All compiled styles
│   └── js/
│       └── serenova.js                ← Three.js, GSAP, preloader, animations
│
└── template-parts/
    ├── preloader.php                  ← 3-panel map preloader
    ├── section-hero.php               ← Hero + Three.js canvas
    ├── section-stats.php              ← Animated counter strip
    ├── section-offerings.php          ← Six pillars grid
    ├── section-courses.php            ← Course cards + short courses
    ├── section-why.php                ← Why Serenova
    ├── section-schedule.php           ← Weekly schedule strip
    ├── section-testimonials.php       ← Testimonials (CPT-aware)
    └── section-newsletter.php         ← Newsletter with AJAX subscribe
```

---

## WordPress Customizer Options

Navigate to **Appearance → Customize** to edit:

| Section | Options |
|---|---|
| **Hero Section** | Eyebrow text, Title lines, Subheading |
| **Contact & Location** | Address, Email, Phone |
| **Social Media Links** | Twitter/X, LinkedIn, Instagram, YouTube |

---

## Custom Post Types

The theme registers three CPTs accessible in the WordPress admin sidebar:

| CPT | Purpose |
|---|---|
| **Testimonials** | Add real member reviews — replaces static fallback when posts exist |
| **Courses** | Manage course/program entries (for future dynamic rendering) |
| **Subscribers** | Stores newsletter signups from the AJAX subscribe form |

### Adding a Testimonial
1. Admin → **Testimonials → Add New**
2. Title = member name  
3. Content = testimonial text  
4. Add a custom field: `serenova_role` = e.g. "Marketing Director · 2 years"
5. Optionally set a featured image (used as avatar)

---

## Navigation Menu

1. Admin → **Appearance → Menus** → Create a menu
2. Assign it to the **Primary Navigation** location
3. Add anchor links (e.g. `#offerings`, `#courses`, `#newsletter`) as custom links

---

## Newsletter AJAX

The subscribe form in the newsletter section submits via `wp_ajax` to the WordPress back-end. Emails are stored as `serenova_subscriber` posts. To export subscribers:

```php
// Add to functions.php or a plugin
$subs = get_posts(['post_type' => 'serenova_subscriber', 'numberposts' => -1]);
foreach ($subs as $s) echo $s->post_title . "\n";
```

---

## External Dependencies (CDN)

These are loaded automatically via `functions.php`:

- **Google Fonts** — Cormorant Garamond, DM Sans, Marcellus
- **GSAP 3.12.5** + ScrollTrigger — scroll animations
- **Three.js r128** — hero particle field & 3D elements

No build step required. Everything works out of the box.

---

## Customising Content

All section content is in `template-parts/`. Each file is plain PHP/HTML — edit text directly or extend with ACF/custom fields for full CMS control.

---

## Requirements

- WordPress 6.0+
- PHP 7.4+
- Modern browser (Chrome, Firefox, Safari, Edge)
