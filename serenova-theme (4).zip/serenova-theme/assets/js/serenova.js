/* ============================================================
   Serenova — Main JS
   v2.0 — Full mobile/touch support
   ============================================================ */

// ─── HELPERS ─────────────────────────────────────────────────
const isTouchDevice = () =>
  ('ontouchstart' in window) || (navigator.maxTouchPoints > 0) ||
  window.matchMedia('(pointer: coarse)').matches;
const isReducedMotion = () =>
  window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const isMobile = () => window.innerWidth <= 768;

// ─── THREE.JS PARTICLE FIELD ─────────────────────────────────
(function () {
  const canvas = document.getElementById('hero-canvas');
  if (!canvas) return;
  if (window.innerWidth < 480 || isReducedMotion()) { canvas.style.display = 'none'; return; }
  if (typeof THREE === 'undefined') return;
  try {
    const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: !isMobile() });
    const scene    = new THREE.Scene();
    const camera   = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.z = 50;
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, isMobile() ? 1 : 2));
    const count = isMobile() ? 800 : 2000;
    const geo = new THREE.BufferGeometry();
    const positions = new Float32Array(count * 3);
    const colors    = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      positions[i*3]=(Math.random()-.5)*200; positions[i*3+1]=(Math.random()-.5)*200; positions[i*3+2]=(Math.random()-.5)*80;
      const r=Math.random();
      if(r<.33){colors[i*3]=.48;colors[i*3+1]=.62;colors[i*3+2]=.49;}
      else if(r<.66){colors[i*3]=.79;colors[i*3+1]=.66;colors[i*3+2]=.30;}
      else{colors[i*3]=.96;colors[i*3+1]=.94;colors[i*3+2]=.91;}
    }
    geo.setAttribute('position',new THREE.BufferAttribute(positions,3));
    geo.setAttribute('color',new THREE.BufferAttribute(colors,3));
    const mat=new THREE.PointsMaterial({size:.35,vertexColors:true,transparent:true,opacity:.7});
    const particles=new THREE.Points(geo,mat); scene.add(particles);
    const sphere=new THREE.Mesh(new THREE.SphereGeometry(22,24,24),new THREE.MeshBasicMaterial({color:0x7a9e7e,wireframe:true,transparent:true,opacity:.06})); scene.add(sphere);
    const torus=new THREE.Mesh(new THREE.TorusGeometry(30,.5,8,80),new THREE.MeshBasicMaterial({color:0xc9a84c,transparent:true,opacity:.08}));
    torus.rotation.x=Math.PI/4; scene.add(torus);
    let mx=0,my=0;
    if(!isTouchDevice()){document.addEventListener('mousemove',e=>{mx=(e.clientX/window.innerWidth-.5)*.3;my=-(e.clientY/window.innerHeight-.5)*.3;});}
    else if(window.DeviceOrientationEvent){window.addEventListener('deviceorientation',e=>{mx=((e.gamma||0)/45)*.15;my=((e.beta||0)/90)*.1;});}
    let t=0,running=true;
    function animate(){if(!running)return;requestAnimationFrame(animate);t+=.004;particles.rotation.y=t*.04+mx*.5;particles.rotation.x=my*.3;sphere.rotation.y=t*.15;sphere.rotation.x=t*.07;torus.rotation.z=t*.08;torus.rotation.y=t*.05;renderer.render(scene,camera);}
    animate();
    window.addEventListener('resize',()=>{camera.aspect=window.innerWidth/window.innerHeight;camera.updateProjectionMatrix();renderer.setSize(window.innerWidth,window.innerHeight);});
    document.addEventListener('visibilitychange',()=>{running=!document.hidden;if(running)animate();});
  } catch(e){console.warn('Three.js init failed',e);}
})();

// ─── GSAP INIT ───────────────────────────────────────────────
if(typeof gsap!=='undefined') gsap.registerPlugin(ScrollTrigger);

// ─── MAP PRELOADER (TOUCH + CLICK FIXED) ─────────────────────
(function () {
  const preloader = document.getElementById('map-preloader');
  if (!preloader) return;
  const panelLeft  = document.getElementById('panelLeft');
  const panelRight = document.getElementById('panelRight');
  const mapCover   = document.getElementById('mapCover');
  const mapWelcome = document.getElementById('mapWelcome');
  const mapHint    = document.getElementById('mapHint');
  const hintLabel  = document.getElementById('hintLabel');
  const hdots = [document.getElementById('hdot0'),document.getElementById('hdot1'),document.getElementById('hdot2')];
  const hintTexts = [
    isTouchDevice() ? 'Tap to unfold your journey' : 'Click to unfold your journey',
    'Keep unfolding\u2026', 'One last fold\u2026'
  ];
  if (hintLabel) hintLabel.textContent = hintTexts[0];

  let mapClicks = 0, processing = false;

  function dismiss() {
    if (typeof gsap !== 'undefined') {
      gsap.to(preloader,{opacity:0,scale:1.04,duration:1.1,ease:'power2.in',onComplete:()=>{preloader.style.display='none';heroEntrance();}});
    } else { preloader.style.display='none'; heroEntrance(); }
  }

  function onTap(e) {
    // Block ghost click on touch devices
    if (e.type==='click' && isTouchDevice()) return;
    if (e.cancelable) e.preventDefault();
    if (processing || mapClicks >= 3) return;
    processing = true;
    setTimeout(()=>{processing=false;}, 700);

    mapClicks++;
    if (hdots[mapClicks-1]) hdots[mapClicks-1].classList.add('lit');

    if (mapClicks === 1) {
      if (typeof gsap!=='undefined'&&panelRight) gsap.to(panelRight,{rotateY:0,duration:1.05,ease:'power3.inOut'});
      if (hintLabel) hintLabel.textContent = hintTexts[1];
    } else if (mapClicks === 2) {
      if (typeof gsap!=='undefined'&&panelLeft) gsap.to(panelLeft,{rotateY:0,duration:1.05,ease:'power3.inOut'});
      if (hintLabel) hintLabel.textContent = hintTexts[2];
    } else if (mapClicks === 3) {
      if (typeof gsap!=='undefined') {
        if(mapCover) gsap.to(mapCover,{rotateX:-180,duration:1.3,ease:'power3.inOut'});
        if(mapHint)  gsap.to(mapHint,{opacity:0,y:8,duration:.35});
      } else if(mapCover) { mapCover.style.display='none'; }
      setTimeout(()=>{
        if (typeof gsap!=='undefined'&&mapWelcome) {
          gsap.to(mapWelcome,{opacity:1,duration:.9,ease:'power2.out',onComplete:()=>setTimeout(dismiss,2400)});
        } else { setTimeout(dismiss,800); }
      }, 1200);
    }
  }

  // CRITICAL: both touchstart AND click
  preloader.addEventListener('touchstart', onTap, { passive: false });
  preloader.addEventListener('click', onTap);
  preloader.addEventListener('touchend', e=>{ if(e.cancelable) e.preventDefault(); }, { passive: false });
})();

// ─── HERO ENTRANCE ───────────────────────────────────────────
function heroEntrance() {
  if (typeof gsap==='undefined'||isReducedMotion()) return;
  gsap.timeline()
    .to('.line-inner',{y:'0%',duration:isMobile()?.8:1.2,stagger:.12,ease:'power4.out'})
    .to('#heroEyebrow',{opacity:1,y:0,duration:.8,ease:'power2.out'},'-=0.8')
    .to('#heroSub',{opacity:1,y:0,duration:.8,ease:'power2.out'},'-=0.5')
    .to('#heroActions',{opacity:1,y:0,duration:.8,ease:'power2.out'},'-=0.4');
}

// ─── NAVBAR SCROLL ───────────────────────────────────────────
window.addEventListener('scroll',()=>{
  const nav=document.getElementById('navbar');
  if(nav) nav.classList.toggle('scrolled',window.scrollY>60);
  const h=document.documentElement;
  const p=window.scrollY/(h.scrollHeight-h.clientHeight);
  if(typeof gsap!=='undefined') gsap.set('#progress-bar',{scaleX:p});
},{passive:true});

// ─── HAMBURGER NAV ───────────────────────────────────────────
(function(){
  const hamburger=document.getElementById('navHamburger');
  const drawer=document.getElementById('navDrawer');
  const overlay=document.getElementById('navOverlay');
  if(!hamburger||!drawer) return;

  function open(){hamburger.classList.add('open');drawer.classList.add('open');if(overlay)overlay.classList.add('open');document.body.style.overflow='hidden';hamburger.setAttribute('aria-expanded','true');}
  function close(){hamburger.classList.remove('open');drawer.classList.remove('open');if(overlay)overlay.classList.remove('open');document.body.style.overflow='';hamburger.setAttribute('aria-expanded','false');}

  hamburger.addEventListener('click',()=>drawer.classList.contains('open')?close():open());
  if(overlay) overlay.addEventListener('click',close);
  drawer.querySelectorAll('a').forEach(a=>a.addEventListener('click',close));
  document.addEventListener('keydown',e=>{if(e.key==='Escape')close();});
})();

// ─── SCROLL ANIMATIONS ───────────────────────────────────────
if(typeof gsap!=='undefined'&&!isReducedMotion()){
  gsap.utils.toArray('.stat-number').forEach(el=>{
    const target=parseInt(el.dataset.target);
    ScrollTrigger.create({trigger:el,start:'top 88%',once:true,onEnter:()=>{
      gsap.to({val:0},{val:target,duration:2,ease:'power2.out',onUpdate:function(){el.textContent=Math.round(this.targets()[0].val).toLocaleString()+(target>99?'+':'');}});
    }});
  });

  gsap.utils.toArray('.reveal-up').forEach(el=>gsap.to(el,{opacity:1,y:0,duration:.9,ease:'power2.out',scrollTrigger:{trigger:el,start:'top 88%',once:true}}));

  if(!isMobile()){
    gsap.utils.toArray('.reveal-left').forEach(el=>gsap.to(el,{opacity:1,x:0,duration:1,ease:'power2.out',scrollTrigger:{trigger:el,start:'top 78%',once:true}}));
    gsap.utils.toArray('.reveal-right').forEach(el=>gsap.to(el,{opacity:1,x:0,duration:1,ease:'power2.out',scrollTrigger:{trigger:el,start:'top 78%',once:true}}));
  } else {
    gsap.utils.toArray('.reveal-left,.reveal-right').forEach(el=>gsap.to(el,{opacity:1,duration:.8,ease:'power2.out',scrollTrigger:{trigger:el,start:'top 88%',once:true}}));
  }

  gsap.utils.toArray('.offer-card').forEach((c,i)=>gsap.fromTo(c,{opacity:0,y:50,scale:.97},{opacity:1,y:0,scale:1,duration:.75,ease:'power2.out',delay:i*(isMobile()?.05:.08),scrollTrigger:{trigger:'#offerings',start:'top 75%',once:true}}));
  gsap.to('#marqueeText',{x:'-40%',duration:30,ease:'none',repeat:-1});
  gsap.utils.toArray('.section-title').forEach(el=>gsap.fromTo(el,{opacity:0,y:28},{opacity:1,y:0,duration:1,ease:'power2.out',scrollTrigger:{trigger:el,start:'top 84%',once:true}}));

  if(!isMobile()){
    gsap.to('.orb-1',{y:-80,scrollTrigger:{trigger:'#hero',scrub:2}});
    gsap.to('.orb-2',{y:60,scrollTrigger:{trigger:'#hero',scrub:1.5}});
  }

  gsap.utils.toArray('.course-card').forEach((c,i)=>gsap.fromTo(c,{opacity:0,y:50},{opacity:1,y:0,duration:.9,ease:'power2.out',delay:i*.12,scrollTrigger:{trigger:'#courses',start:'top 75%',once:true}}));
  gsap.utils.toArray('.testimonial-card').forEach((c,i)=>gsap.fromTo(c,{opacity:0,y:35},{opacity:1,y:0,duration:.8,ease:'power2.out',delay:i*.1,scrollTrigger:{trigger:'#testimonials',start:'top 78%',once:true}}));
  gsap.utils.toArray('.day-col').forEach((c,i)=>gsap.fromTo(c,{opacity:0,y:24},{opacity:1,y:0,duration:.55,ease:'power2.out',delay:i*.06,scrollTrigger:{trigger:'#schedule-strip',start:'top 88%',once:true}}));
  gsap.fromTo('.why-accent-box',{scale:.85,opacity:0,rotate:-5},{scale:1,opacity:1,rotate:0,duration:1.1,ease:'back.out(1.4)',scrollTrigger:{trigger:'#why',start:'top 75%',once:true}});
  gsap.fromTo('.newsletter-content',{opacity:0,y:45},{opacity:1,y:0,duration:1,ease:'power2.out',scrollTrigger:{trigger:'#newsletter',start:'top 82%',once:true}});
}

// ─── CUSTOM CURSOR (Desktop only) ────────────────────────────
(function(){
  if(isTouchDevice()){
    ['cursor','cursorRing'].forEach(id=>{const el=document.getElementById(id);if(el)el.style.display='none';});
    return;
  }
  if(typeof gsap==='undefined') return;
  const cursor=document.getElementById('cursor');
  const ring=document.getElementById('cursorRing');
  if(!cursor||!ring) return;
  let cx=0,cy=0,rx=0,ry=0;
  document.addEventListener('mousemove',e=>{cx=e.clientX;cy=e.clientY;gsap.set(cursor,{x:cx-4,y:cy-4});});
  gsap.ticker.add(()=>{rx+=(cx-rx)*.12;ry+=(cy-ry)*.12;gsap.set(ring,{x:rx-18,y:ry-18});});
  document.querySelectorAll('button,a,.offer-card,.course-card').forEach(el=>{
    el.addEventListener('mouseenter',()=>{gsap.to(ring,{scale:2,opacity:.5,duration:.3});gsap.to(cursor,{scale:0,duration:.3});});
    el.addEventListener('mouseleave',()=>{gsap.to(ring,{scale:1,opacity:1,duration:.3});gsap.to(cursor,{scale:1,duration:.3});});
  });
})();

// ─── ENROLL BUTTONS ──────────────────────────────────────────
document.querySelectorAll('.enroll-btn').forEach(btn=>{
  btn.addEventListener('click',function(){
    if(typeof gsap!=='undefined') gsap.to(this,{scale:.95,duration:.1,yoyo:true,repeat:1});
    const orig=this.textContent; this.textContent='✓ Added!';
    setTimeout(()=>{this.textContent=orig;},2500);
  });
});

// ─── SMOOTH ANCHOR SCROLL ────────────────────────────────────
document.querySelectorAll('a[href^="#"]').forEach(a=>{
  a.addEventListener('click',function(e){
    const t=document.querySelector(this.getAttribute('href'));
    if(!t) return;
    e.preventDefault();
    t.scrollIntoView({behavior:'smooth',block:'start'});
  });
});
