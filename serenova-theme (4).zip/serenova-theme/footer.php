<?php
$address   = serenova_get( 'serenova_address',   'Gurugram, Haryana' );
$email     = serenova_get( 'serenova_email',     'hello@serenova.in' );
$phone     = serenova_get( 'serenova_phone',     '+91 98765 43210' );
$twitter   = serenova_get( 'serenova_twitter',   '#' );
$linkedin  = serenova_get( 'serenova_linkedin',  '#' );
$instagram = serenova_get( 'serenova_instagram', '#' );
$youtube   = serenova_get( 'serenova_youtube',   '#' );
?>

<footer>
  <div class="footer-top">
    <div class="footer-brand">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="footer-logo">Sere<span>nova</span></a>
      <p class="footer-tagline">A sanctuary for those who believe that wellbeing is not a destination — it's a way of living.</p>
    </div>
    <div class="footer-col">
      <h5>Offerings</h5>
      <ul>
        <li><a href="#offerings">Yoga &amp; Breathwork</a></li>
        <li><a href="#offerings">Swimming Programs</a></li>
        <li><a href="#offerings">Stress Management</a></li>
        <li><a href="#offerings">Diet &amp; Nutrition</a></li>
        <li><a href="#offerings">Mindfulness</a></li>
        <li><a href="#offerings">Workshops</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h5>Company</h5>
      <ul>
        <li><a href="<?php echo esc_url( home_url( '/our-story' ) ); ?>">Our Story</a></li>
        <li><a href="<?php echo esc_url( home_url( '/faculty' ) ); ?>">Faculty</a></li>
        <li><a href="<?php echo esc_url( home_url( '/research' ) ); ?>">Research</a></li>
        <li><a href="<?php echo esc_url( home_url( '/press' ) ); ?>">Press</a></li>
        <li><a href="<?php echo esc_url( home_url( '/careers' ) ); ?>">Careers</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h5>Contact</h5>
      <ul>
        <li><a href="#"><?php echo esc_html( $address ); ?></a></li>
        <li><a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a></li>
        <li><a href="tel:<?php echo esc_attr( preg_replace( '/\s+/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a></li>
        <li><a href="#">Book a Tour</a></li>
      </ul>
    </div>
  </div>
  <div class="footer-bottom">
    <span class="footer-copy">© <?php echo date( 'Y' ); ?> Serenova Wellness Studio. All rights reserved.</span>
    <div class="social-links">
      <a href="<?php echo esc_url( $twitter ); ?>" class="social-link" target="_blank" rel="noopener noreferrer" aria-label="Twitter">𝕏</a>
      <a href="<?php echo esc_url( $linkedin ); ?>" class="social-link" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">in</a>
      <a href="<?php echo esc_url( $instagram ); ?>" class="social-link" target="_blank" rel="noopener noreferrer" aria-label="Instagram">ig</a>
      <a href="<?php echo esc_url( $youtube ); ?>" class="social-link" target="_blank" rel="noopener noreferrer" aria-label="YouTube">yt</a>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
