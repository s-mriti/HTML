<?php
/**
 * Front Page Template
 *
 * This is the main landing page for Serenova.
 * WordPress uses this file when "Your homepage displays: A static page"
 * is selected in Settings → Reading, OR when viewing the site root.
 *
 * @package Serenova
 */

get_header();
?>

<?php get_template_part( 'template-parts/preloader' ); ?>

<?php get_template_part( 'template-parts/section', 'hero' ); ?>

<?php get_template_part( 'template-parts/section', 'stats' ); ?>

<?php get_template_part( 'template-parts/section', 'offerings' ); ?>

<?php get_template_part( 'template-parts/section', 'courses' ); ?>

<?php get_template_part( 'template-parts/section', 'why' ); ?>

<?php get_template_part( 'template-parts/section', 'schedule' ); ?>

<?php get_template_part( 'template-parts/section', 'testimonials' ); ?>

<?php get_template_part( 'template-parts/section', 'newsletter' ); ?>

<?php get_footer(); ?>
