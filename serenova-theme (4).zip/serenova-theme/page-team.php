<?php
/**
 * Template Name: Team Page
 *
 * Assign this template to any WordPress Page to display the team.
 * Create via: Pages → Add New → Page Attributes → Template → "Team Page"
 *
 * @package Serenova
 */

get_header();

$team_query = new WP_Query( [
	'post_type'      => 'serenova_team',
	'posts_per_page' => -1,
	'post_status'    => 'publish',
	'orderby'        => 'menu_order',
	'order'          => 'ASC',
] );

$joinus_url    = serenova_get( 'serenova_joinus_url',   '#' );
$joinus_label  = serenova_get( 'serenova_joinus_label', 'Join Us' );
$joinus_target = serenova_get( 'serenova_joinus_target', '_blank' );
?>

<style>
/* ─── Team Page Styles ─── */
.team-page {
  background: var(--warm-white);
  min-height: 100vh;
  overflow-x: hidden;
}

/* ── Hero Banner ── */
.team-hero {
  background: linear-gradient(150deg, var(--deep-green) 0%, var(--forest) 55%, #3d7a52 100%);
  padding: 160px 60px 100px;
  position: relative;
  overflow: hidden;
}
.team-hero::before {
  content: 'TEAM';
  position: absolute;
  top: 50%; left: 50%;
  transform: translate(-50%, -50%);
  font-family: 'Marcellus', serif;
  font-size: clamp(100px, 20vw, 240px);
  color: rgba(122,158,126,0.06);
  letter-spacing: 0.2em;
  white-space: nowrap;
  pointer-events: none;
}
.team-hero-inner {
  max-width: 1200px;
  margin: 0 auto;
  position: relative;
  z-index: 2;
}
.team-hero-label {
  font-size: 11px;
  letter-spacing: 0.45em;
  text-transform: uppercase;
  color: var(--gold);
  opacity: 0.8;
  display: block;
  margin-bottom: 20px;
}
.team-hero-title {
  font-family: 'Marcellus', serif;
  font-size: clamp(36px, 7vw, 80px);
  color: var(--cream);
  line-height: 1.05;
  margin-bottom: 24px;
  letter-spacing: 0.02em;
}
.team-hero-title em {
  font-family: 'Cormorant Garamond', serif;
  font-style: italic;
  color: var(--gold);
  font-weight: 300;
}
.team-hero-sub {
  font-size: 16px;
  color: rgba(245,240,232,0.55);
  line-height: 1.8;
  max-width: 520px;
  font-weight: 300;
}
.team-hero-divider {
  width: 60px; height: 1px;
  background: linear-gradient(to right, var(--gold), transparent);
  margin: 32px 0;
}

/* Decorative orbs */
.team-hero-orb {
  position: absolute;
  border-radius: 50%;
  pointer-events: none;
}
.team-hero-orb-1 {
  width: 400px; height: 400px;
  top: -100px; right: -80px;
  background: radial-gradient(circle, rgba(122,158,126,0.12) 0%, transparent 70%);
}
.team-hero-orb-2 {
  width: 250px; height: 250px;
  bottom: -60px; left: 10%;
  background: radial-gradient(circle, rgba(201,168,76,0.08) 0%, transparent 70%);
}

/* ── Stats Bar ── */
.team-stats-bar {
  background: var(--deep-green);
  padding: 0 60px;
  display: flex;
  justify-content: center;
  gap: 0;
  border-bottom: 1px solid rgba(201,168,76,0.15);
}
.team-stat {
  padding: 28px 48px;
  text-align: center;
  border-right: 1px solid rgba(201,168,76,0.1);
  flex: 1;
  max-width: 200px;
}
.team-stat:last-child { border-right: none; }
.team-stat-num {
  font-family: 'Cormorant Garamond', serif;
  font-size: 32px;
  color: var(--gold);
  display: block;
  line-height: 1;
}
.team-stat-label {
  font-size: 10px;
  letter-spacing: 0.2em;
  text-transform: uppercase;
  color: rgba(245,240,232,0.4);
  display: block;
  margin-top: 6px;
}

/* ── Section Header ── */
.team-section-header {
  text-align: center;
  padding: 80px 60px 20px;
  max-width: 700px;
  margin: 0 auto;
}
.team-section-label {
  font-size: 11px;
  letter-spacing: 0.45em;
  text-transform: uppercase;
  color: var(--sage);
  display: block;
  margin-bottom: 16px;
}
.team-section-title {
  font-family: 'Marcellus', serif;
  font-size: clamp(28px, 4vw, 48px);
  color: var(--deep-green);
  line-height: 1.15;
}
.team-section-title em {
  font-family: 'Cormorant Garamond', serif;
  font-style: italic;
  color: var(--forest);
  font-weight: 300;
}
.team-section-desc {
  margin-top: 16px;
  font-size: 15px;
  line-height: 1.8;
  color: rgba(42,42,42,0.5);
  font-weight: 300;
}

/* ── Team Grid ── */
.team-grid-wrap {
  padding: 40px 60px 100px;
  max-width: 1300px;
  margin: 0 auto;
}
.team-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 32px;
}

/* ── Team Card ── */
.team-card {
  background: #fff;
  border-radius: 4px;
  overflow: hidden;
  border: 1px solid rgba(122,158,126,0.12);
  transition: all 0.4s ease;
  position: relative;
  box-shadow: 0 4px 24px rgba(26,58,42,0.05);
}
.team-card:hover {
  transform: translateY(-8px);
  box-shadow: 0 20px 60px rgba(26,58,42,0.12);
  border-color: rgba(201,168,76,0.3);
}

/* Photo area */
.team-card-photo {
  position: relative;
  height: 300px;
  overflow: hidden;
  background: linear-gradient(145deg, var(--mist), #d5e0d6);
}
.team-card-photo img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.6s ease;
}
.team-card:hover .team-card-photo img {
  transform: scale(1.06);
}
/* Placeholder when no image */
.team-card-photo-placeholder {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(145deg, #e8ede9, #d0dcd1);
  font-size: 64px;
  color: var(--sage);
}
.team-card-photo-overlay {
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 80px;
  background: linear-gradient(to top, rgba(26,58,42,0.4), transparent);
  pointer-events: none;
}

/* Social links on photo */
.team-card-socials {
  position: absolute;
  top: 16px; right: 16px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  opacity: 0;
  transform: translateX(12px);
  transition: all 0.35s ease;
}
.team-card:hover .team-card-socials {
  opacity: 1;
  transform: translateX(0);
}
.team-card-social-link {
  width: 36px; height: 36px;
  background: rgba(255,255,255,0.92);
  backdrop-filter: blur(8px);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: 600;
  color: var(--deep-green);
  text-decoration: none;
  transition: background 0.2s, color 0.2s;
  border: 1px solid rgba(26,58,42,0.1);
}
.team-card-social-link:hover {
  background: var(--gold);
  color: var(--deep-green);
}

/* Card body */
.team-card-body {
  padding: 28px 28px 24px;
}
.team-card-name {
  font-family: 'Marcellus', serif;
  font-size: 22px;
  color: var(--deep-green);
  margin-bottom: 4px;
  letter-spacing: 0.02em;
}
.team-card-role {
  font-size: 12px;
  letter-spacing: 0.2em;
  text-transform: uppercase;
  color: var(--sage);
  font-weight: 500;
  display: block;
  margin-bottom: 12px;
}
.team-card-speciality {
  font-size: 12px;
  color: var(--gold);
  letter-spacing: 0.08em;
  margin-bottom: 14px;
  display: block;
  opacity: 0.8;
}
.team-card-divider {
  width: 30px; height: 1px;
  background: linear-gradient(to right, var(--sage), transparent);
  margin: 14px 0;
}
.team-card-bio {
  font-size: 13px;
  line-height: 1.75;
  color: rgba(42,42,42,0.6);
  font-weight: 300;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.team-card-quote {
  margin-top: 16px;
  padding: 12px 16px;
  border-left: 2px solid var(--sage);
  background: rgba(122,158,126,0.04);
  border-radius: 0 2px 2px 0;
}
.team-card-quote p {
  font-family: 'Cormorant Garamond', serif;
  font-size: 14px;
  font-style: italic;
  color: rgba(42,42,42,0.55);
  line-height: 1.6;
  margin: 0;
}

/* ── Empty State ── */
.team-empty {
  grid-column: 1 / -1;
  text-align: center;
  padding: 80px 40px;
}
.team-empty-icon { font-size: 48px; margin-bottom: 20px; display: block; }
.team-empty h3 {
  font-family: 'Marcellus', serif;
  font-size: 24px;
  color: var(--deep-green);
  margin-bottom: 12px;
}
.team-empty p {
  font-size: 14px;
  color: rgba(42,42,42,0.5);
  line-height: 1.7;
  max-width: 400px;
  margin: 0 auto 24px;
}
.team-empty-steps {
  display: inline-flex;
  flex-direction: column;
  gap: 8px;
  text-align: left;
  background: var(--mist);
  padding: 20px 28px;
  border-radius: 4px;
  font-size: 13px;
  color: var(--forest);
  line-height: 1.8;
}

/* ── Join Us CTA Banner ── */
.team-join-banner {
  background: linear-gradient(135deg, var(--deep-green) 0%, var(--forest) 100%);
  padding: 80px 60px;
  text-align: center;
  position: relative;
  overflow: hidden;
}
.team-join-banner::before {
  content: '';
  position: absolute;
  width: 600px; height: 600px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(201,168,76,0.06) 0%, transparent 70%);
  top: 50%; left: 50%;
  transform: translate(-50%, -50%);
  pointer-events: none;
}
.team-join-inner {
  position: relative;
  z-index: 2;
  max-width: 640px;
  margin: 0 auto;
}
.team-join-label {
  font-size: 11px;
  letter-spacing: 0.4em;
  text-transform: uppercase;
  color: var(--gold);
  opacity: 0.7;
  display: block;
  margin-bottom: 20px;
}
.team-join-title {
  font-family: 'Marcellus', serif;
  font-size: clamp(28px, 4vw, 44px);
  color: var(--cream);
  margin-bottom: 16px;
  letter-spacing: 0.02em;
  line-height: 1.2;
}
.team-join-title em {
  font-family: 'Cormorant Garamond', serif;
  font-style: italic;
  color: var(--gold);
  font-weight: 300;
}
.team-join-sub {
  font-size: 15px;
  color: rgba(245,240,232,0.45);
  line-height: 1.8;
  font-weight: 300;
  margin-bottom: 36px;
}
.team-join-btn {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  padding: 18px 44px;
  background: var(--gold);
  color: var(--deep-green);
  font-family: 'DM Sans', sans-serif;
  font-size: 13px;
  font-weight: 600;
  letter-spacing: 0.18em;
  text-transform: uppercase;
  text-decoration: none;
  border-radius: 2px;
  transition: all 0.3s ease;
  box-shadow: 0 8px 32px rgba(201,168,76,0.25);
}
.team-join-btn:hover {
  background: #d4b565;
  transform: translateY(-2px);
  box-shadow: 0 16px 48px rgba(201,168,76,0.35);
  color: var(--deep-green);
}
.team-join-btn-arrow {
  transition: transform 0.3s ease;
}
.team-join-btn:hover .team-join-btn-arrow {
  transform: translateX(4px);
}

/* ── Animations ── */
@keyframes teamFadeUp {
  from { opacity: 0; transform: translateY(30px); }
  to   { opacity: 1; transform: translateY(0); }
}
.team-card {
  animation: teamFadeUp 0.6s ease both;
}
<?php
$i = 1;
for ( $d = 0; $d <= 12; $d++ ) {
	echo ".team-card:nth-child({$i}) { animation-delay: " . ($d * 0.08) . "s; }\n";
	$i++;
}
?>

/* Responsive */
@media (max-width: 900px) {
  .team-hero { padding: 130px 28px 70px; }
  .team-grid-wrap { padding: 32px 24px 60px; }
  .team-stats-bar { flex-wrap: wrap; padding: 0 24px; }
  .team-stat { min-width: 120px; }
  .team-join-banner { padding: 60px 28px; }
  .team-section-header { padding: 60px 28px 16px; }
}
@media (max-width: 600px) {
  .team-grid { grid-template-columns: 1fr; }
  .team-hero-title { font-size: 36px; }
}
</style>

<div class="team-page">

  <!-- Hero Banner -->
  <div class="team-hero">
    <div class="team-hero-orb team-hero-orb-1"></div>
    <div class="team-hero-orb team-hero-orb-2"></div>
    <div class="team-hero-inner">
      <span class="team-hero-label">✦ The People Behind the Practice ✦</span>
      <h1 class="team-hero-title">
        Meet Our <em>Expert</em><br>Wellness Team
      </h1>
      <div class="team-hero-divider"></div>
      <p class="team-hero-sub">
        Every instructor, nutritionist, and guide at Serenova brings decades of lived practice — not just credentials, but genuine transformation.
      </p>
    </div>
  </div>

  <!-- Stats Bar -->
  <div class="team-stats-bar">
    <div class="team-stat">
      <span class="team-stat-num">120+</span>
      <span class="team-stat-label">Expert Instructors</span>
    </div>
    <div class="team-stat">
      <span class="team-stat-num">18+</span>
      <span class="team-stat-label">Disciplines Covered</span>
    </div>
    <div class="team-stat">
      <span class="team-stat-num">98%</span>
      <span class="team-stat-label">Member Satisfaction</span>
    </div>
    <div class="team-stat">
      <span class="team-stat-num">12+</span>
      <span class="team-stat-label">Years Together</span>
    </div>
  </div>

  <!-- Section Header -->
  <div class="team-section-header">
    <span class="team-section-label">Our Faculty</span>
    <h2 class="team-section-title">Guides for Your <em>Journey</em></h2>
    <p class="team-section-desc">Each team member is handpicked not only for their expertise, but for their ability to meet you exactly where you are.</p>
  </div>

  <!-- Team Grid -->
  <div class="team-grid-wrap">
    <div class="team-grid">

      <?php if ( $team_query->have_posts() ) : ?>

        <?php while ( $team_query->have_posts() ) : $team_query->the_post();
          $role       = get_post_meta( get_the_ID(), 'serenova_team_role',       true );
          $speciality = get_post_meta( get_the_ID(), 'serenova_team_speciality', true );
          $linkedin   = get_post_meta( get_the_ID(), 'serenova_team_linkedin',   true );
          $instagram  = get_post_meta( get_the_ID(), 'serenova_team_instagram',  true );
          $email      = get_post_meta( get_the_ID(), 'serenova_team_email',      true );
          $quote      = get_post_meta( get_the_ID(), 'serenova_team_quote',      true );
        ?>

        <div class="team-card">

          <!-- Photo -->
          <div class="team-card-photo">
            <?php if ( has_post_thumbnail() ) : ?>
              <?php the_post_thumbnail( 'large', [ 'loading' => 'lazy', 'alt' => get_the_title() ] ); ?>
            <?php else : ?>
              <div class="team-card-photo-placeholder">🧘</div>
            <?php endif; ?>
            <div class="team-card-photo-overlay"></div>

            <!-- Social icons on hover -->
            <div class="team-card-socials">
              <?php if ( $linkedin ) : ?>
              <a href="<?php echo esc_url( $linkedin ); ?>" target="_blank" rel="noopener noreferrer" class="team-card-social-link" title="LinkedIn">in</a>
              <?php endif; ?>
              <?php if ( $instagram ) : ?>
              <a href="<?php echo esc_url( $instagram ); ?>" target="_blank" rel="noopener noreferrer" class="team-card-social-link" title="Instagram">ig</a>
              <?php endif; ?>
              <?php if ( $email ) : ?>
              <a href="mailto:<?php echo esc_attr( $email ); ?>" class="team-card-social-link" title="Email">@</a>
              <?php endif; ?>
            </div>
          </div>

          <!-- Body -->
          <div class="team-card-body">
            <h3 class="team-card-name"><?php the_title(); ?></h3>
            <?php if ( $role ) : ?>
              <span class="team-card-role"><?php echo esc_html( $role ); ?></span>
            <?php endif; ?>
            <?php if ( $speciality ) : ?>
              <span class="team-card-speciality">✦ <?php echo esc_html( $speciality ); ?></span>
            <?php endif; ?>
            <?php if ( has_excerpt() || get_the_content() ) : ?>
              <div class="team-card-divider"></div>
              <div class="team-card-bio">
                <?php echo wp_trim_words( get_the_excerpt() ?: get_the_content(), 30, '…' ); ?>
              </div>
            <?php endif; ?>
            <?php if ( $quote ) : ?>
              <div class="team-card-quote">
                <p>"<?php echo esc_html( $quote ); ?>"</p>
              </div>
            <?php endif; ?>
          </div>

        </div>

        <?php endwhile; wp_reset_postdata(); ?>

      <?php else : ?>

        <!-- Empty state — shown only to admins when no team members added yet -->
        <div class="team-empty">
          <span class="team-empty-icon">👥</span>
          <h3>No team members yet</h3>
          <p>Add your team from the WordPress admin panel. Each member will appear as a card on this page automatically.</p>
          <?php if ( current_user_can( 'edit_posts' ) ) : ?>
          <div class="team-empty-steps">
            <strong>How to add team members:</strong>
            1. Go to <strong>Team Members → Add New</strong> in your admin<br>
            2. Enter their name as the title<br>
            3. Fill in Role, Speciality, and Quote in the details box<br>
            4. Upload their photo as the Featured Image<br>
            5. Write their bio in the content area<br>
            6. Click <strong>Publish</strong> — they'll appear here instantly
          </div>
          <?php endif; ?>
        </div>

      <?php endif; ?>

    </div>
  </div>

  <!-- Join Us CTA Banner -->
  <div class="team-join-banner">
    <div class="team-join-inner">
      <span class="team-join-label">Become Part of Something Greater</span>
      <h2 class="team-join-title">
        Ready to Start Your<br><em>Wellness Journey?</em>
      </h2>
      <p class="team-join-sub">
        Our team is here to guide you every step of the way — from your first class to your most profound transformation.
      </p>
      <a
        href="<?php echo esc_url( $joinus_url ); ?>"
        target="<?php echo esc_attr( $joinus_target ); ?>"
        rel="<?php echo $joinus_target === '_blank' ? 'noopener noreferrer' : ''; ?>"
        class="team-join-btn"
      >
        <?php echo esc_html( $joinus_label ); ?>
        <span class="team-join-btn-arrow">→</span>
      </a>
    </div>
  </div>

</div><!-- /team-page -->

<?php get_footer(); ?>
