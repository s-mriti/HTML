<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- Progress Bar -->
<div id="progress-bar"></div>

<!-- Custom Cursor (hidden on touch via JS) -->
<div class="cursor" id="cursor"></div>
<div class="cursor-ring" id="cursorRing"></div>

<?php
$joinus_url    = serenova_get( 'serenova_joinus_url',    '#newsletter' );
$joinus_label  = serenova_get( 'serenova_joinus_label',  'Join Us' );
$joinus_target = serenova_get( 'serenova_joinus_target', '_blank' );
$twitter       = serenova_get( 'serenova_twitter',   '#' );
$instagram     = serenova_get( 'serenova_instagram', '#' );
$linkedin      = serenova_get( 'serenova_linkedin',  '#' );
?>

<!-- ═══ MOBILE OVERLAY + DRAWER ═══ -->
<div class="nav-mobile-overlay" id="navOverlay"></div>
<nav class="nav-mobile-drawer" id="navDrawer" aria-label="Mobile Navigation">
  <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="drawer-logo">Sere<span>nova</span></a>
  <ul>
    <li><a href="#offerings">Offerings</a></li>
    <li><a href="#courses">Courses</a></li>
    <li><a href="#why">Why Us</a></li>
    <li><a href="#testimonials">Stories</a></li>
    <li><a href="<?php echo esc_url( home_url( '/team' ) ); ?>">Team</a></li>
    <li><a href="#newsletter">Newsletter</a></li>
  </ul>
  <a
    href="<?php echo esc_url( $joinus_url ); ?>"
    target="<?php echo esc_attr( $joinus_target ); ?>"
    rel="<?php echo $joinus_target === '_blank' ? 'noopener noreferrer' : ''; ?>"
    class="drawer-joinus-btn"
  ><?php echo esc_html( $joinus_label ); ?> →</a>
  <div class="drawer-social">
    <a href="<?php echo esc_url( $twitter ); ?>"   target="_blank" rel="noopener" aria-label="Twitter">𝕏</a>
    <a href="<?php echo esc_url( $instagram ); ?>" target="_blank" rel="noopener" aria-label="Instagram">ig</a>
    <a href="<?php echo esc_url( $linkedin ); ?>"  target="_blank" rel="noopener" aria-label="LinkedIn">in</a>
  </div>
</nav>

<!-- ═══ MAIN NAV ═══ -->
<nav id="navbar" role="navigation" aria-label="Primary Navigation">

  <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="nav-logo" aria-label="Serenova Home">
    <?php if ( has_custom_logo() ) : the_custom_logo();
    else : ?>Sere<span>nova</span><?php endif; ?>
  </a>

  <!-- Desktop links -->
  <?php if ( has_nav_menu( 'primary' ) ) : ?>
    <?php wp_nav_menu([ 'theme_location'=>'primary','container'=>false,'menu_class'=>'nav-links','items_wrap'=>'<ul class="%2$s">%3$s</ul>' ]); ?>
  <?php else : ?>
    <ul class="nav-links" role="menubar">
      <li role="none"><a href="#offerings" role="menuitem">Offerings</a></li>
      <li role="none"><a href="#courses"   role="menuitem">Courses</a></li>
      <li role="none"><a href="#why"       role="menuitem">Why Us</a></li>
      <li role="none"><a href="#testimonials" role="menuitem">Stories</a></li>
      <li role="none"><a href="<?php echo esc_url( home_url( '/team' ) ); ?>" role="menuitem">Team</a></li>
    </ul>
  <?php endif; ?>

  <!-- Desktop Join Us CTA -->
  <a
    href="<?php echo esc_url( $joinus_url ); ?>"
    target="<?php echo esc_attr( $joinus_target ); ?>"
    rel="<?php echo $joinus_target === '_blank' ? 'noopener noreferrer' : ''; ?>"
    class="nav-joinus-btn"
    aria-label="<?php echo esc_attr( $joinus_label ); ?>"
  ><?php echo esc_html( $joinus_label ); ?> <span class="joinus-arrow">→</span></a>

  <!-- Hamburger (mobile only — shown via CSS) -->
  <button
    class="nav-hamburger"
    id="navHamburger"
    aria-label="Open navigation menu"
    aria-controls="navDrawer"
    aria-expanded="false"
    type="button"
  >
    <span></span>
    <span></span>
    <span></span>
  </button>

</nav>
