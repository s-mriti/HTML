<?php
/**
 * Template Part: Why Serenova Section
 *
 * @package Serenova
 */
?>

<section id="why">
  <div class="why-visual reveal-left">
    <div class="why-accent-box">
      <span class="big-num">98%</span>
      <span class="small-text"><?php esc_html_e( 'Client Retention Rate', 'serenova' ); ?></span>
    </div>
    <div class="why-main-img"></div>
    <div style="position:absolute; right:-20px; top:50%; transform:translateY(-50%);
      background:var(--gold); padding:20px 24px; border-radius:2px;
      box-shadow: 0 10px 40px rgba(201,168,76,0.3); max-width:160px; text-align:center;">
      <div style="font-family:'Cormorant Garamond',serif; font-size:28px; color:var(--deep-green); line-height:1;">12+</div>
      <div style="font-size:10px; letter-spacing:0.15em; text-transform:uppercase; color:rgba(26,58,42,0.7); margin-top:4px;"><?php esc_html_e( 'Years Serving', 'serenova' ); ?></div>
    </div>
  </div>

  <div class="why-content reveal-right">
    <span class="section-label"><?php esc_html_e( 'Why Serenova', 'serenova' ); ?></span>
    <h2 class="section-title"><?php esc_html_e( 'Science-backed.', 'serenova' ); ?> <em><?php esc_html_e( 'Soul-centred.', 'serenova' ); ?></em></h2>
    <p style="margin-top:20px; font-size:15px; line-height:1.8; color:rgba(42,42,42,0.55); font-weight:300;"><?php esc_html_e( 'We don\'t believe in one-size-fits-all wellness. Every member receives a curated experience built around their unique needs.', 'serenova' ); ?></p>

    <div class="why-points">
      <div class="why-point">
        <div class="why-point-icon">🏅</div>
        <div class="why-point-text">
          <h4><?php esc_html_e( 'Certified Expert Faculty', 'serenova' ); ?></h4>
          <p><?php esc_html_e( 'All instructors hold internationally recognised certifications and are trained in trauma-informed practices.', 'serenova' ); ?></p>
        </div>
      </div>
      <div class="why-point">
        <div class="why-point-icon">🔬</div>
        <div class="why-point-text">
          <h4><?php esc_html_e( 'Evidence-Based Approach', 'serenova' ); ?></h4>
          <p><?php esc_html_e( 'Programs designed in collaboration with neuroscientists, nutritionists, and physiotherapists.', 'serenova' ); ?></p>
        </div>
      </div>
      <div class="why-point">
        <div class="why-point-icon">♾️</div>
        <div class="why-point-text">
          <h4><?php esc_html_e( 'Holistic Integration', 'serenova' ); ?></h4>
          <p><?php esc_html_e( 'Our six pillars work together — progress in one area amplifies results across all others, creating compounding wellbeing.', 'serenova' ); ?></p>
        </div>
      </div>
    </div>
  </div>
</section>
