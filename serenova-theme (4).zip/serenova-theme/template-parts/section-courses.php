<?php
/**
 * Template Part: Courses Section
 *
 * @package Serenova
 */

$courses = [
  [
    'level'    => 'Beginner',
    'name'     => 'Foundations of Wellness',
    'desc'     => 'A gentle introduction to yoga, breath, and nutrition — perfect for those starting their wellness journey with no prior experience.',
    'features' => [
      '3× weekly yoga sessions',
      'Personalised diet consultation',
      'Weekly mindfulness circle',
      'Access to member app',
    ],
    'featured' => false,
  ],
  [
    'level'    => 'Intermediate',
    'name'     => 'Total Transformation',
    'desc'     => 'Our flagship program combining all six pillars — yoga, swimming, stress management, diet, mindfulness, and a monthly workshop.',
    'features' => [
      '5× weekly multi-discipline sessions',
      'Full aqua fitness access',
      'Monthly 1:1 nutritionist session',
      'Stress lab + biofeedback tools',
      '2 weekend workshops included',
    ],
    'featured' => true,
  ],
  [
    'level'    => 'Advanced',
    'name'     => 'Elite Membership',
    'desc'     => 'Unlimited access to everything Serenova offers — including private coaching, premium retreats, and priority booking for all events.',
    'features' => [
      'Unlimited classes — all disciplines',
      'Monthly private coaching',
      'Quarterly wellness retreat',
      'Priority workshop access',
      'Dedicated wellness concierge',
    ],
    'featured' => false,
  ],
];

$short_courses = [
  [ 'icon' => '🧘‍♀️', 'title' => 'Prenatal Yoga' ],
  [ 'icon' => '🏊‍♂️', 'title' => 'Kids Swim School' ],
  [ 'icon' => '🌙',    'title' => 'Sleep Reset Program' ],
  [ 'icon' => '🥗',    'title' => 'Gut Health Detox' ],
];
?>

<section id="courses">
  <div class="courses-header">
    <span class="section-label"><?php esc_html_e( 'Our Programs', 'serenova' ); ?></span>
    <h2 class="section-title"><?php esc_html_e( 'Choose Your', 'serenova' ); ?> <em><?php esc_html_e( 'Path', 'serenova' ); ?></em></h2>
    <p style="margin-top:20px; font-size:15px; line-height:1.8; color:rgba(245,240,232,0.45); font-weight:300; max-width:480px;"><?php esc_html_e( 'Structured courses designed for real transformation — not just fitness, but a complete lifestyle elevation.', 'serenova' ); ?></p>
  </div>

  <div class="courses-scroll">
    <?php foreach ( $courses as $course ) : ?>
    <div class="course-card <?php echo $course['featured'] ? 'featured' : ''; ?> reveal-up">
      <?php if ( $course['featured'] ) : ?>
      <div class="featured-badge"><?php esc_html_e( 'Most Popular', 'serenova' ); ?></div>
      <?php endif; ?>
      <span class="course-level"><?php echo esc_html( $course['level'] ); ?></span>
      <h3 class="course-name"><?php echo esc_html( $course['name'] ); ?></h3>
      <p class="course-desc"><?php echo esc_html( $course['desc'] ); ?></p>
      <ul class="course-features">
        <?php foreach ( $course['features'] as $feature ) : ?>
        <li><?php echo esc_html( $feature ); ?></li>
        <?php endforeach; ?>
      </ul>
      <button class="enroll-btn"><?php esc_html_e( 'Enroll Now', 'serenova' ); ?></button>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Specialty Short Courses -->
  <div style="margin-top: 60px;">
    <h3 style="font-family:'Cormorant Garamond',serif; font-size:28px; font-weight:300; color:rgba(245,240,232,0.7); margin-bottom:32px; letter-spacing:0.02em;"><?php esc_html_e( 'Specialty Short Courses', 'serenova' ); ?></h3>
    <div style="display:grid; grid-template-columns:repeat(4,1fr); gap:16px;">
      <?php foreach ( $short_courses as $sc ) : ?>
      <div style="padding:28px 24px; border:1px solid rgba(201,168,76,0.12); background:rgba(245,240,232,0.03); border-radius:2px; transition:all 0.3s;"
           onmouseover="this.style.borderColor='rgba(201,168,76,0.4)'" onmouseout="this.style.borderColor='rgba(201,168,76,0.12)'">
        <div style="font-size:28px; margin-bottom:12px;"><?php echo $sc['icon']; ?></div>
        <div style="font-family:'Cormorant Garamond',serif; font-size:18px; color:var(--cream); margin-bottom:8px;"><?php echo esc_html( $sc['title'] ); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
