<?php
/**
 * Template Part: Offerings Section
 *
 * @package Serenova
 */

$offerings = [
  [
    'icon'  => '🧘',
    'tag'   => 'Mind & Body',
    'title' => 'Yoga & Breathwork',
    'desc'  => 'From Hatha to Vinyasa, our certified instructors guide all levels through transformative practices rooted in ancient tradition.',
    'bg'    => 'card-bg-yoga',
  ],
  [
    'icon'  => '🏊',
    'tag'   => 'All Ages Welcome',
    'title' => 'Swimming & Aqua Fitness',
    'desc'  => 'Structured programs for toddlers to seniors — including therapeutic aqua therapy, competitive training, and recreational swimming.',
    'bg'    => 'card-bg-swim',
  ],
  [
    'icon'  => '🧠',
    'tag'   => 'Mental Wellness',
    'title' => 'Stress Management',
    'desc'  => 'Evidence-based techniques including CBT approaches, somatic therapy, and guided relaxation to rebalance your nervous system.',
    'bg'    => 'card-bg-stress',
  ],
  [
    'icon'  => '🥗',
    'tag'   => 'Nutrition Science',
    'title' => 'Personalised Diet Plans',
    'desc'  => 'Nutritionist-designed meal plans tailored to your metabolism, goals, and lifestyle — plant-based, therapeutic, and performance-focused.',
    'bg'    => 'card-bg-diet',
  ],
  [
    'icon'  => '🌊',
    'tag'   => 'Inner Peace',
    'title' => 'Mindfulness & Meditation',
    'desc'  => 'Guided MBSR sessions, sound bowl therapy, and silent retreats designed to cultivate deep presence and lasting equanimity.',
    'bg'    => 'card-bg-mindful',
  ],
  [
    'icon'  => '🎯',
    'tag'   => 'Community',
    'title' => 'Workshops & Retreats',
    'desc'  => 'Monthly themed workshops, weekend immersions, and annual retreats that deepen your practice within a thriving community.',
    'bg'    => 'card-bg-workshop',
  ],
];
?>

<section id="offerings">
  <div class="offerings-header">
    <span class="section-label"><?php esc_html_e( 'What We Offer', 'serenova' ); ?></span>
    <h2 class="section-title"><?php esc_html_e( 'Six Pillars of', 'serenova' ); ?> <em><?php esc_html_e( 'Holistic', 'serenova' ); ?></em> <?php esc_html_e( 'Wellness', 'serenova' ); ?></h2>
    <p style="margin-top:20px; font-size:15px; line-height:1.8; color:rgba(42,42,42,0.55); font-weight:300; max-width:480px;"><?php esc_html_e( 'Each discipline is designed to work in harmony, creating a complete ecosystem for your wellbeing journey.', 'serenova' ); ?></p>
  </div>

  <div class="offerings-grid">
    <?php foreach ( $offerings as $index => $offering ) : ?>
    <div class="offer-card" data-index="<?php echo esc_attr( $index ); ?>">
      <div class="card-bg <?php echo esc_attr( $offering['bg'] ); ?>"></div>
      <div class="card-pattern"></div>
      <div class="offer-card-inner">
        <div class="offer-icon"><?php echo $offering['icon']; ?></div>
        <span class="offer-tag"><?php echo esc_html( $offering['tag'] ); ?></span>
        <h3 class="offer-title"><?php echo esc_html( $offering['title'] ); ?></h3>
        <p class="offer-desc"><?php echo esc_html( $offering['desc'] ); ?></p>
        <span class="offer-cta"><?php esc_html_e( 'Explore →', 'serenova' ); ?></span>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <div class="parallax-text" id="marqueeText">YOGA · SWIMMING · MINDFULNESS · WELLNESS · DIET · WORKSHOPS · YOGA · SWIMMING · MINDFULNESS · </div>
</section>
