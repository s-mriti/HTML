<?php
/**
 * Template Part: Hero Section
 *
 * @package Serenova
 */

$eyebrow  = serenova_get( 'serenova_hero_eyebrow',     '✦ Holistic Wellness Redefined ✦' );
$line1    = serenova_get( 'serenova_hero_title_line1', 'Transform Your' );
$line2    = serenova_get( 'serenova_hero_title_line2', 'Mind, Body' );
$hero_sub = serenova_get( 'serenova_hero_sub',         'A sanctuary where ancient wisdom meets modern science — crafted for those who seek lasting change, not just momentary relief.' );
?>

<section id="hero">
  <canvas id="hero-canvas"></canvas>

  <div class="hero-bg-orbs">
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>
    <div class="orb orb-3"></div>
  </div>

  <!-- 3D Cube decorations -->
  <div style="position:absolute; top:15%; left:8%; z-index:2; perspective:400px;">
    <div class="cube-3d">
      <div class="cube-face front"></div>
      <div class="cube-face back"></div>
      <div class="cube-face left"></div>
      <div class="cube-face right"></div>
      <div class="cube-face top"></div>
      <div class="cube-face bottom"></div>
    </div>
  </div>
  <div style="position:absolute; top:65%; right:12%; z-index:2; perspective:400px;">
    <div class="cube-3d" style="animation-duration: 16s; width:40px; height:40px;">
      <div class="cube-face front" style="width:40px;height:40px;"></div>
      <div class="cube-face back" style="width:40px;height:40px;transform:rotateY(180deg) translateZ(20px);"></div>
      <div class="cube-face left" style="width:40px;height:40px;transform:rotateY(-90deg) translateZ(20px);"></div>
      <div class="cube-face right" style="width:40px;height:40px;transform:rotateY(90deg) translateZ(20px);"></div>
      <div class="cube-face top" style="width:40px;height:40px;transform:rotateX(90deg) translateZ(20px);"></div>
      <div class="cube-face bottom" style="width:40px;height:40px;transform:rotateX(-90deg) translateZ(20px);"></div>
    </div>
  </div>

  <div class="hero-content">
    <div class="hero-eyebrow" id="heroEyebrow"><?php echo esc_html( $eyebrow ); ?></div>
    <h1 class="hero-title">
      <span class="line"><span class="line-inner"><?php echo esc_html( $line1 ); ?></span></span>
      <span class="line"><span class="line-inner"><em><?php echo esc_html( $line2 ); ?></em></span></span>
      <span class="line"><span class="line-inner">&amp; Spirit</span></span>
    </h1>
    <p class="hero-sub" id="heroSub"><?php echo esc_html( $hero_sub ); ?></p>
    <div class="hero-actions" id="heroActions">
      <button class="btn-primary" onclick="document.getElementById('offerings').scrollIntoView({behavior:'smooth'})"><?php esc_html_e( 'Explore Programs', 'serenova' ); ?></button>
      <button class="btn-ghost" onclick="document.getElementById('courses').scrollIntoView({behavior:'smooth'})"><?php esc_html_e( 'View Courses', 'serenova' ); ?></button>
    </div>
  </div>

  <div class="hero-scroll-hint">
    <div class="scroll-line"></div>
    <span><?php esc_html_e( 'Scroll', 'serenova' ); ?></span>
  </div>
</section>
