<?php
/**
 * Template Part: Weekly Schedule Strip
 *
 * @package Serenova
 */

$schedule = [
  'Monday'    => [ ['Hatha Yoga', '6:00 AM'], ['Aqua Fitness', '10:00 AM'], ['Meditation', '7:00 PM'] ],
  'Tuesday'   => [ ['Vinyasa Flow', '6:30 AM'], ['Swim School', '11:00 AM'], ['Stress Lab', '6:30 PM'] ],
  'Wednesday' => [ ['Yin Yoga', '7:00 AM'], ['Diet Consult', '12:00 PM'], ['Sound Healing', '7:30 PM'] ],
  'Thursday'  => [ ['Power Yoga', '6:00 AM'], ['Kids Swim', '10:30 AM'], ['MBSR Circle', '6:00 PM'] ],
  'Friday'    => [ ['Breathwork', '6:30 AM'], ['Lap Swimming', '9:00 AM'], ['Restorative', '7:00 PM'] ],
  'Saturday'  => [ ['Community Yoga', '7:00 AM'], ['Open Swim', '10:00 AM'], ['Workshop', '4:00 PM'] ],
  'Sunday'    => [ ['Slow Flow', '8:00 AM'], ['Family Swim', '11:00 AM'], ['Rest & Reflect', '5:00 PM'] ],
];
?>

<section id="schedule-strip">
  <?php foreach ( $schedule as $day => $classes ) : ?>
  <div class="day-col">
    <span class="day-name"><?php echo esc_html( $day ); ?></span>
    <?php foreach ( $classes as $class ) : ?>
    <span class="day-class"><?php echo esc_html( $class[0] ); ?></span>
    <span class="day-time"><?php echo esc_html( $class[1] ); ?></span>
    <?php endforeach; ?>
  </div>
  <?php endforeach; ?>
</section>
