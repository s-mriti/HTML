<?php
/**
 * Template Part: Map Preloader
 *
 * @package Serenova
 */
?>
<div id="map-preloader">
  <div class="pre-ambient"></div>
  <div class="pre-ghost">SERENOVA</div>

  <!-- Ambient particles -->
  <div class="fp" style="width:5px;height:5px;left:12%;top:0;background:rgba(201,168,76,0.18);animation-duration:9s;animation-delay:0s;"></div>
  <div class="fp" style="width:3px;height:3px;left:28%;top:0;background:rgba(122,158,126,0.2);animation-duration:12s;animation-delay:2s;"></div>
  <div class="fp" style="width:6px;height:6px;left:55%;top:0;background:rgba(201,168,76,0.12);animation-duration:8s;animation-delay:1s;"></div>
  <div class="fp" style="width:4px;height:4px;left:72%;top:0;background:rgba(122,158,126,0.15);animation-duration:14s;animation-delay:3s;"></div>
  <div class="fp" style="width:3px;height:3px;left:88%;top:0;background:rgba(201,168,76,0.2);animation-duration:10s;animation-delay:0.5s;"></div>
  <div class="fp" style="width:5px;height:5px;left:40%;top:0;background:rgba(196,113,74,0.12);animation-duration:11s;animation-delay:4s;"></div>

  <div class="map-scene">
    <div class="map-book" id="mapBook">

      <!-- LEFT PANEL -->
      <div class="map-panel" id="panelLeft">
        <svg width="260" height="480" viewBox="0 0 260 480" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <radialGradient id="pgL" cx="60%" cy="40%" r="80%">
              <stop offset="0%" stop-color="#f7f0d8"/>
              <stop offset="100%" stop-color="#e4d09a"/>
            </radialGradient>
          </defs>
          <rect width="260" height="480" fill="url(#pgL)"/>
          <rect x="230" width="30" height="480" fill="rgba(0,0,0,0.07)"/>
          <g stroke="#8a6e2a" stroke-width="0.5" opacity="0.22">
            <line x1="0" y1="48" x2="260" y2="48"/><line x1="0" y1="96" x2="260" y2="96"/>
            <line x1="0" y1="144" x2="260" y2="144"/><line x1="0" y1="192" x2="260" y2="192"/>
            <line x1="0" y1="240" x2="260" y2="240"/><line x1="0" y1="288" x2="260" y2="288"/>
            <line x1="0" y1="336" x2="260" y2="336"/><line x1="0" y1="384" x2="260" y2="384"/>
            <line x1="0" y1="432" x2="260" y2="432"/>
            <line x1="48" y1="0" x2="48" y2="480"/><line x1="96" y1="0" x2="96" y2="480"/>
            <line x1="144" y1="0" x2="144" y2="480"/><line x1="192" y1="0" x2="192" y2="480"/>
            <line x1="240" y1="0" x2="240" y2="480"/>
          </g>
          <!-- Decorative wellness map elements -->
          <circle cx="80" cy="120" r="30" fill="none" stroke="#7a9e7e" stroke-width="1" opacity="0.5"/>
          <circle cx="80" cy="120" r="18" fill="rgba(122,158,126,0.12)" stroke="#7a9e7e" stroke-width="0.5" opacity="0.4"/>
          <text x="80" y="125" text-anchor="middle" font-family="serif" font-size="10" fill="#2d5a3d" opacity="0.7">YOGA</text>
          <circle cx="190" cy="200" r="24" fill="none" stroke="#c9a84c" stroke-width="1" opacity="0.45"/>
          <text x="190" y="204" text-anchor="middle" font-family="serif" font-size="9" fill="#8a6e2a" opacity="0.7">SWIM</text>
          <line x1="110" y1="120" x2="166" y2="200" stroke="#8a6e2a" stroke-width="0.8" stroke-dasharray="3,3" opacity="0.3"/>
          <circle cx="100" cy="330" r="20" fill="none" stroke="#c4714a" stroke-width="0.8" opacity="0.4"/>
          <text x="100" y="334" text-anchor="middle" font-family="serif" font-size="8" fill="#6b3d22" opacity="0.6">MIND</text>
          <line x1="190" y1="224" x2="115" y2="313" stroke="#8a6e2a" stroke-width="0.8" stroke-dasharray="3,3" opacity="0.3"/>
          <!-- Compass rose -->
          <g transform="translate(200,390)">
            <circle r="22" fill="none" stroke="#8a6e2a" stroke-width="0.7" opacity="0.35"/>
            <line x1="0" y1="-18" x2="0" y2="18" stroke="#8a6e2a" stroke-width="0.8" opacity="0.4"/>
            <line x1="-18" y1="0" x2="18" y2="0" stroke="#8a6e2a" stroke-width="0.8" opacity="0.4"/>
            <polygon points="0,-14 3,-4 -3,-4" fill="#c9a84c" opacity="0.6"/>
            <text x="0" y="-24" text-anchor="middle" font-size="7" fill="#8a6e2a" opacity="0.5" font-family="serif">N</text>
          </g>
          <!-- Legend -->
          <rect x="14" y="370" width="120" height="70" rx="2" fill="rgba(245,240,232,0.6)" stroke="#8a6e2a" stroke-width="0.5" opacity="0.5"/>
          <text x="74" y="385" text-anchor="middle" font-family="serif" font-size="8" fill="#2d3a28" opacity="0.7" font-style="italic">Serenova Wellness</text>
          <line x1="20" y1="390" x2="130" y2="390" stroke="#8a6e2a" stroke-width="0.4" opacity="0.3"/>
          <circle cx="24" cy="402" r="3" fill="#7a9e7e" opacity="0.6"/>
          <text x="32" y="405" font-size="7" fill="#3a3020" opacity="0.6" font-family="sans-serif">Yoga &amp; Breath</text>
          <circle cx="24" cy="416" r="3" fill="#c9a84c" opacity="0.6"/>
          <text x="32" y="419" font-size="7" fill="#3a3020" opacity="0.6" font-family="sans-serif">Aquatics</text>
          <circle cx="24" cy="430" r="3" fill="#c4714a" opacity="0.6"/>
          <text x="32" y="433" font-size="7" fill="#3a3020" opacity="0.6" font-family="sans-serif">Mindfulness</text>
        </svg>
        <div class="fold-crease" style="right:0;"></div>
      </div>

      <!-- CENTER PANEL -->
      <div class="map-panel" id="panelCenter">
        <svg width="260" height="480" viewBox="0 0 260 480" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <radialGradient id="pgC" cx="50%" cy="50%" r="70%">
              <stop offset="0%" stop-color="#f2e8c8"/>
              <stop offset="100%" stop-color="#ddc88a"/>
            </radialGradient>
            <radialGradient id="hubGrad" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stop-color="#2d5a3d"/>
              <stop offset="100%" stop-color="#1a3a2a"/>
            </radialGradient>
          </defs>
          <rect width="260" height="480" fill="url(#pgC)"/>
          <g stroke="#8a6e2a" stroke-width="0.5" opacity="0.18">
            <line x1="0" y1="48" x2="260" y2="48"/><line x1="0" y1="96" x2="260" y2="96"/>
            <line x1="0" y1="144" x2="260" y2="144"/><line x1="0" y1="192" x2="260" y2="192"/>
            <line x1="0" y1="240" x2="260" y2="240"/><line x1="0" y1="288" x2="260" y2="288"/>
            <line x1="0" y1="336" x2="260" y2="336"/><line x1="0" y1="384" x2="260" y2="384"/>
            <line x1="48" y1="0" x2="48" y2="480"/><line x1="96" y1="0" x2="96" y2="480"/>
            <line x1="144" y1="0" x2="144" y2="480"/><line x1="192" y1="0" x2="192" y2="480"/>
          </g>
          <!-- Central hub -->
          <circle cx="130" cy="220" r="55" fill="url(#hubGrad)" opacity="0.85"/>
          <circle cx="130" cy="220" r="55" fill="none" stroke="#c9a84c" stroke-width="1.5" opacity="0.6"/>
          <circle cx="130" cy="220" r="42" fill="none" stroke="rgba(201,168,76,0.3)" stroke-width="0.8"/>
          <text x="130" y="213" text-anchor="middle" font-family="serif" font-size="13" fill="#f5f0e8" letter-spacing="2" font-style="italic">Sere</text>
          <text x="130" y="231" text-anchor="middle" font-family="serif" font-size="13" fill="#c9a84c" letter-spacing="2">nova</text>
          <!-- Radiating paths -->
          <line x1="130" y1="165" x2="130" y2="60" stroke="#8a6e2a" stroke-width="1" stroke-dasharray="4,3" opacity="0.4"/>
          <line x1="130" y1="275" x2="130" y2="430" stroke="#8a6e2a" stroke-width="1" stroke-dasharray="4,3" opacity="0.4"/>
          <line x1="75" y1="220" x2="20" y2="220" stroke="#8a6e2a" stroke-width="1" stroke-dasharray="4,3" opacity="0.4"/>
          <line x1="185" y1="220" x2="240" y2="220" stroke="#8a6e2a" stroke-width="1" stroke-dasharray="4,3" opacity="0.4"/>
          <!-- Destination dots -->
          <circle cx="130" cy="55" r="6" fill="#7a9e7e" opacity="0.8"/>
          <text x="130" y="42" text-anchor="middle" font-size="8" fill="#2d3a28" opacity="0.75" font-family="serif">YOGA</text>
          <circle cx="130" cy="435" r="6" fill="#c4714a" opacity="0.8"/>
          <text x="130" y="453" text-anchor="middle" font-size="8" fill="#2d3a28" opacity="0.75" font-family="serif">DIET</text>
          <circle cx="15" cy="220" r="6" fill="#8b7ba8" opacity="0.8"/>
          <text x="8" y="208" text-anchor="middle" font-size="7.5" fill="#2d3a28" opacity="0.75" font-family="serif">MIND</text>
          <circle cx="245" cy="220" r="6" fill="#c9a84c" opacity="0.8"/>
          <text x="252" y="208" text-anchor="middle" font-size="7.5" fill="#2d3a28" opacity="0.75" font-family="serif">SWIM</text>
          <!-- Title banner -->
          <rect x="10" y="10" width="240" height="30" rx="1" fill="rgba(26,58,42,0.08)" stroke="#8a6e2a" stroke-width="0.5" opacity="0.5"/>
          <text x="130" y="30" text-anchor="middle" font-family="serif" font-size="11" fill="#2d3a28" opacity="0.8" letter-spacing="3" font-style="italic">Wellness Journey Map</text>
        </svg>

        <!-- Map Cover (lifts on 3rd click) -->
        <div id="mapCover">
          <div class="cover-border-outer"></div>
          <div class="cover-border-inner"></div>
          <div class="cover-corner tl"></div>
          <div class="cover-corner tr"></div>
          <div class="cover-corner bl"></div>
          <div class="cover-corner br"></div>
          <span class="cover-eyebrow">Est. <?php echo date('Y') - 12; ?> · Gurugram</span>
          <div class="cover-logo">Sere<span>nova</span></div>
          <p class="cover-tagline">Holistic Wellness Studio</p>
          <div class="cover-divider"></div>
          <span class="cover-click">Click to begin</span>
        </div>

        <div class="fold-crease" style="left:0;"></div>
        <div class="fold-crease" style="right:0;"></div>

        <!-- Welcome Overlay -->
        <div id="mapWelcome">
          <span class="wlc-star">✦ ✦ ✦</span>
          <div class="wlc-name">Sere<span>nova</span></div>
          <div class="wlc-bar"></div>
          <p class="wlc-msg"><?php echo esc_html( serenova_get( 'serenova_hero_sub', 'Your journey to wholeness begins here.' ) ); ?></p>
          <span class="wlc-loc">Gurugram · Haryana · India</span>
          <span class="wlc-enter">Enter ↓</span>
        </div>
      </div>

      <!-- RIGHT PANEL -->
      <div class="map-panel" id="panelRight">
        <svg width="260" height="480" viewBox="0 0 260 480" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <radialGradient id="pgR" cx="40%" cy="60%" r="80%">
              <stop offset="0%" stop-color="#f7f0d8"/>
              <stop offset="100%" stop-color="#e4d09a"/>
            </radialGradient>
          </defs>
          <rect width="260" height="480" fill="url(#pgR)"/>
          <rect x="0" width="30" height="480" fill="rgba(0,0,0,0.06)"/>
          <g stroke="#8a6e2a" stroke-width="0.5" opacity="0.22">
            <line x1="0" y1="48" x2="260" y2="48"/><line x1="0" y1="96" x2="260" y2="96"/>
            <line x1="0" y1="144" x2="260" y2="144"/><line x1="0" y1="192" x2="260" y2="192"/>
            <line x1="0" y1="240" x2="260" y2="240"/><line x1="0" y1="288" x2="260" y2="288"/>
            <line x1="0" y1="336" x2="260" y2="336"/><line x1="0" y1="384" x2="260" y2="384"/>
            <line x1="0" y1="432" x2="260" y2="432"/>
            <line x1="48" y1="0" x2="48" y2="480"/><line x1="96" y1="0" x2="96" y2="480"/>
            <line x1="144" y1="0" x2="144" y2="480"/><line x1="192" y1="0" x2="192" y2="480"/>
            <line x1="240" y1="0" x2="240" y2="480"/>
          </g>
          <!-- Schedule elements -->
          <rect x="30" y="30" width="200" height="20" rx="2" fill="rgba(26,58,42,0.08)" stroke="#8a6e2a" stroke-width="0.5" opacity="0.5"/>
          <text x="130" y="44" text-anchor="middle" font-size="9" fill="#2d3a28" opacity="0.8" font-family="serif" letter-spacing="2">WEEKLY SCHEDULE</text>
          <!-- Day rows -->
          <g font-family="sans-serif" font-size="8" fill="#3a3020" opacity="0.75">
            <text x="40" y="80" font-weight="bold" opacity="0.9">MON</text><text x="90" y="80">Hatha Yoga · 6:00 AM</text>
            <line x1="30" y1="86" x2="230" y2="86" stroke="#8a6e2a" stroke-width="0.3" opacity="0.3"/>
            <text x="40" y="106" font-weight="bold" opacity="0.9">TUE</text><text x="90" y="106">Vinyasa · 6:30 AM</text>
            <line x1="30" y1="112" x2="230" y2="112" stroke="#8a6e2a" stroke-width="0.3" opacity="0.3"/>
            <text x="40" y="132" font-weight="bold" opacity="0.9">WED</text><text x="90" y="132">Yin Yoga · 7:00 AM</text>
            <line x1="30" y1="138" x2="230" y2="138" stroke="#8a6e2a" stroke-width="0.3" opacity="0.3"/>
            <text x="40" y="158" font-weight="bold" opacity="0.9">THU</text><text x="90" y="158">Power Yoga · 6:00 AM</text>
            <line x1="30" y1="164" x2="230" y2="164" stroke="#8a6e2a" stroke-width="0.3" opacity="0.3"/>
            <text x="40" y="184" font-weight="bold" opacity="0.9">FRI</text><text x="90" y="184">Breathwork · 6:30 AM</text>
            <line x1="30" y1="190" x2="230" y2="190" stroke="#8a6e2a" stroke-width="0.3" opacity="0.3"/>
            <text x="40" y="210" font-weight="bold" opacity="0.9">SAT</text><text x="90" y="210">Community Yoga · 7AM</text>
            <line x1="30" y1="216" x2="230" y2="216" stroke="#8a6e2a" stroke-width="0.3" opacity="0.3"/>
            <text x="40" y="236" font-weight="bold" opacity="0.9">SUN</text><text x="90" y="236">Slow Flow · 8:00 AM</text>
          </g>
          <!-- Stamp -->
          <g transform="translate(175,330)">
            <circle r="38" fill="none" stroke="#c9a84c" stroke-width="1.5" opacity="0.5" stroke-dasharray="2,2"/>
            <circle r="30" fill="none" stroke="#c9a84c" stroke-width="0.7" opacity="0.3"/>
            <text y="-8" text-anchor="middle" font-size="7.5" fill="#8a6e2a" opacity="0.8" font-family="serif" letter-spacing="1">SINCE</text>
            <text y="5" text-anchor="middle" font-size="16" fill="#c9a84c" opacity="0.85" font-family="serif"><?php echo date('Y') - 12; ?></text>
            <text y="18" text-anchor="middle" font-size="6.5" fill="#8a6e2a" opacity="0.6" font-family="serif" letter-spacing="1">SERENOVA</text>
          </g>
          <!-- Path lines -->
          <path d="M50,260 Q80,290 60,330 Q40,370 70,410" fill="none" stroke="#7a9e7e" stroke-width="1.5" stroke-dasharray="5,4" opacity="0.35"/>
          <path d="M100,260 Q130,300 110,350 Q90,400 120,440" fill="none" stroke="#c9a84c" stroke-width="1" stroke-dasharray="4,4" opacity="0.3"/>
        </svg>
        <div class="fold-crease" style="left:0;"></div>
      </div>

    </div><!-- /map-book -->
  </div><!-- /map-scene -->

  <div id="mapHint">
    <span class="hint-label" id="hintLabel">Click to unfold your journey</span>
    <span class="hint-icon">☟</span>
    <div class="hint-dots">
      <span class="hdot" id="hdot0"></span>
      <span class="hdot" id="hdot1"></span>
      <span class="hdot" id="hdot2"></span>
    </div>
  </div>

</div><!-- /map-preloader -->
