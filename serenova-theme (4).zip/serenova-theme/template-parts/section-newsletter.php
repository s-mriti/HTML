<?php
/**
 * Template Part: Newsletter Section
 *
 * @package Serenova
 */
?>

<section id="newsletter">
  <div class="newsletter-content">
    <span class="section-label" style="color:var(--sage);"><?php esc_html_e( 'Stay Connected', 'serenova' ); ?></span>
    <h2 class="newsletter-title"><?php esc_html_e( 'Begin Your', 'serenova' ); ?> <em><?php esc_html_e( 'Journey', 'serenova' ); ?></em> <?php esc_html_e( 'Today', 'serenova' ); ?></h2>
    <p class="newsletter-sub"><?php esc_html_e( 'Subscribe for weekly wellness insights, class schedules, and early access to our seasonal retreats and workshops.', 'serenova' ); ?></p>

    <div class="newsletter-form" id="serenovaNewsletterForm">
      <input
        type="email"
        class="newsletter-input"
        id="serenovaEmailInput"
        placeholder="<?php esc_attr_e( 'Your email address', 'serenova' ); ?>"
      >
      <button class="newsletter-btn" id="serenovaSubscribeBtn">
        <?php esc_html_e( 'Subscribe', 'serenova' ); ?>
      </button>
    </div>
    <p id="serenovaNewsletterMsg" style="margin-top:16px; font-size:13px; color:var(--sage); min-height:20px; transition:all 0.3s;"></p>
    <p style="margin-top:8px; font-size:12px; color:rgba(245,240,232,0.25); letter-spacing:0.05em;"><?php esc_html_e( 'No spam, ever. Unsubscribe anytime.', 'serenova' ); ?></p>
  </div>
</section>

<script>
(function() {
  const btn   = document.getElementById('serenovaSubscribeBtn');
  const input = document.getElementById('serenovaEmailInput');
  const msg   = document.getElementById('serenovaNewsletterMsg');

  if (!btn || !input) return;

  btn.addEventListener('click', function() {
    const email = input.value.trim();
    if (!email) { msg.textContent = '<?php esc_html_e( 'Please enter your email.', 'serenova' ); ?>'; return; }

    btn.disabled = true;
    btn.textContent = '<?php esc_html_e( 'Sending…', 'serenova' ); ?>';

    var formData = new FormData();
    formData.append('action', 'serenova_newsletter');
    formData.append('email', email);
    formData.append('nonce', serenovaData.nonce);

    fetch(serenovaData.ajaxUrl, { method: 'POST', body: formData })
      .then(r => r.json())
      .then(data => {
        msg.textContent = data.data ? data.data.message : '<?php esc_html_e( 'Thank you!', 'serenova' ); ?>';
        input.value = '';
      })
      .catch(() => {
        msg.textContent = '<?php esc_html_e( 'Something went wrong. Please try again.', 'serenova' ); ?>';
      })
      .finally(() => {
        btn.disabled = false;
        btn.textContent = '<?php esc_html_e( 'Subscribe', 'serenova' ); ?>';
      });
  });
})();
</script>
