<?php
/**
 * Template Part: Testimonials Section
 *
 * Uses the 'serenova_testimonial' CPT if posts exist,
 * otherwise falls back to static defaults.
 *
 * @package Serenova
 */

$testimonials_query = new WP_Query( [
  'post_type'      => 'serenova_testimonial',
  'posts_per_page' => 3,
  'post_status'    => 'publish',
] );

$use_cpt = $testimonials_query->have_posts();

$static_testimonials = [
  [
    'text'   => 'Serenova didn\'t just help me get fit — it completely changed how I relate to my body and mind. The combination of yoga and stress management sessions was exactly what I needed after years of corporate burnout.',
    'name'   => 'Priya Mehta',
    'role'   => 'Marketing Director · Member for 2 years',
    'avatar' => '🌸',
    'stars'  => 5,
  ],
  [
    'text'   => 'My 7-year-old learnt to swim in 6 weeks and I lost 12kg following my personalised diet plan. It\'s become a family affair — we all attend different programs and meet for the Saturday community yoga.',
    'name'   => 'Rahul Sharma',
    'role'   => 'Engineer · Member for 18 months',
    'avatar' => '🌿',
    'stars'  => 5,
  ],
  [
    'text'   => 'The mindfulness workshops changed my relationship with anxiety entirely. The instructors here don\'t just teach techniques — they teach you to understand yourself. Worth every rupee and more.',
    'name'   => 'Anika Bose',
    'role'   => 'Architect · Member for 3 years',
    'avatar' => '🌊',
    'stars'  => 5,
  ],
];
?>

<section id="testimonials">
  <div class="testimonials-bg-text"><?php esc_html_e( 'Stories', 'serenova' ); ?></div>
  <span class="section-label"><?php esc_html_e( 'Member Stories', 'serenova' ); ?></span>
  <h2 class="section-title"><?php esc_html_e( 'Real Lives,', 'serenova' ); ?> <em><?php esc_html_e( 'Real Change', 'serenova' ); ?></em></h2>

  <div class="testimonials-grid">

    <?php if ( $use_cpt ) : ?>
      <?php while ( $testimonials_query->have_posts() ) : $testimonials_query->the_post(); ?>
      <div class="testimonial-card reveal-up">
        <span class="quote-mark">"</span>
        <p class="testimonial-text"><?php the_content(); ?></p>
        <div class="testimonial-author">
          <div class="author-avatar">
            <?php if ( has_post_thumbnail() ) : ?>
              <?php the_post_thumbnail( 'thumbnail' ); ?>
            <?php else : ?>
              🌿
            <?php endif; ?>
          </div>
          <div>
            <span class="author-name"><?php the_title(); ?></span>
            <span class="author-role"><?php echo esc_html( get_post_meta( get_the_ID(), 'serenova_role', true ) ); ?></span>
            <div class="star-rating">★★★★★</div>
          </div>
        </div>
      </div>
      <?php endwhile; wp_reset_postdata(); ?>

    <?php else : ?>
      <?php foreach ( $static_testimonials as $t ) : ?>
      <div class="testimonial-card reveal-up">
        <span class="quote-mark">"</span>
        <p class="testimonial-text"><?php echo esc_html( $t['text'] ); ?></p>
        <div class="testimonial-author">
          <div class="author-avatar"><?php echo $t['avatar']; ?></div>
          <div>
            <span class="author-name"><?php echo esc_html( $t['name'] ); ?></span>
            <span class="author-role"><?php echo esc_html( $t['role'] ); ?></span>
            <div class="star-rating"><?php echo str_repeat( '★', $t['stars'] ); ?></div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    <?php endif; ?>

  </div>
</section>
