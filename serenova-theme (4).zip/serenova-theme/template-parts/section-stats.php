<?php
/**
 * Template Part: Stats Section
 *
 * @package Serenova
 */
?>
<section id="stats">
  <div class="stat-item reveal-up">
    <span class="stat-number" data-target="4800">0</span>
    <span class="stat-label"><?php esc_html_e( 'Members Transformed', 'serenova' ); ?></span>
  </div>
  <div class="stat-item reveal-up">
    <span class="stat-number" data-target="120">0</span>
    <span class="stat-label"><?php esc_html_e( 'Expert Instructors', 'serenova' ); ?></span>
  </div>
  <div class="stat-item reveal-up">
    <span class="stat-number" data-target="38">0</span>
    <span class="stat-label"><?php esc_html_e( 'Programs Available', 'serenova' ); ?></span>
  </div>
  <div class="stat-item reveal-up">
    <span class="stat-number" data-target="12">0</span>
    <span class="stat-label"><?php esc_html_e( 'Years of Excellence', 'serenova' ); ?></span>
  </div>
</section>
